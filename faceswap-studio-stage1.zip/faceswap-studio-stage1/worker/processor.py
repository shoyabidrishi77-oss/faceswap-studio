import argparse
import json
import os
import sys
from pathlib import Path

import cv2

MAX_BYTES = 100 * 1024 * 1024
ALLOWED_EXTENSIONS = {".mp4", ".mov"}


def inspect_video(path: str) -> dict:
    video = Path(path)

    if not video.is_file():
        raise ValueError("Video file was not found.")

    if video.suffix.lower() not in ALLOWED_EXTENSIONS:
        raise ValueError("Only MP4 and MOV videos are accepted.")

    size = video.stat().st_size
    if size <= 0 or size > MAX_BYTES:
        raise ValueError("Video must be non-empty and no larger than 100 MB.")

    cap = cv2.VideoCapture(str(video))
    if not cap.isOpened():
        raise ValueError("The video could not be opened.")

    try:
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = float(cap.get(cv2.CAP_PROP_FPS))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        if frame_count <= 0 or fps <= 0 or width <= 0 or height <= 0:
            raise ValueError("The video metadata is invalid.")

        detector_path = (
            cv2.data.haarcascades
            + "haarcascade_frontalface_default.xml"
        )
        detector = cv2.CascadeClassifier(detector_path)
        if detector.empty():
            raise RuntimeError("Face detector could not be loaded.")

        # Sample at most 12 evenly spaced frames for a quick preflight.
        sample_count = min(frame_count, 12)
        indexes = sorted({
            int(i * (frame_count - 1) / max(sample_count - 1, 1))
            for i in range(sample_count)
        })

        observed_face_counts = []
        for index in indexes:
            cap.set(cv2.CAP_PROP_POS_FRAMES, index)
            ok, frame = cap.read()
            if not ok:
                continue

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = detector.detectMultiScale(
                gray, scaleFactor=1.1, minNeighbors=5,
                minSize=(40, 40)
            )
            observed_face_counts.append(len(faces))

        if not observed_face_counts:
            raise ValueError("Could not read sampled video frames.")

        if not any(count == 1 for count in observed_face_counts):
            raise ValueError("No single detectable face was found in sampled frames.")

        if any(count > 1 for count in observed_face_counts):
            raise ValueError(
                "Multiple faces were detected in at least one sampled frame. "
                "This starter rejects ambiguous videos."
            )

        return {
            "ok": True,
            "filename": video.name,
            "size_bytes": size,
            "width": width,
            "height": height,
            "fps": round(fps, 3),
            "frame_count": frame_count,
            "duration_seconds": round(frame_count / fps, 2),
            "sampled_frames": len(observed_face_counts),
            "preflight": "passed",
            "notice": (
                "Face detection is only a basic preflight check; "
                "it does not verify identity, liveness, or consent."
            ),
        }
    finally:
        cap.release()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="FaceSwap Studio video preflight CLI (no face replacement)."
    )
    parser.add_argument("--video", required=True, help="Path to MP4 or MOV")
    args = parser.parse_args()

    try:
        result = inspect_video(args.video)
        print(json.dumps(result, indent=2))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, indent=2))
        return 1


if __name__ == "__main__":
    sys.exit(main())
