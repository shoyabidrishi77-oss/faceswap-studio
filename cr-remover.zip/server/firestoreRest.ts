export interface FirestoreConfigRef {
  projectId: string;
  firestoreDatabaseId: string;
}

type FirestoreValue =
  | { stringValue: string }
  | { integerValue: string }
  | { doubleValue: number }
  | { booleanValue: boolean }
  | { timestampValue: string }
  | { nullValue: null };

interface FirestoreDocumentRaw {
  name: string;
  fields?: Record<string, FirestoreValue>;
  createTime?: string;
  updateTime?: string;
}

function getBaseUrl(config: FirestoreConfigRef): string {
  const dbId = config.firestoreDatabaseId || '(default)';
  return `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(config.projectId)}/databases/${encodeURIComponent(dbId)}/documents`;
}

export function fromFirestoreValue(val: FirestoreValue): unknown {
  if ('stringValue' in val) return val.stringValue;
  if ('integerValue' in val) return Number.parseInt(val.integerValue, 10);
  if ('doubleValue' in val) return val.doubleValue;
  if ('booleanValue' in val) return val.booleanValue;
  if ('timestampValue' in val) return val.timestampValue;
  if ('nullValue' in val) return null;
  return null;
}

export function toFirestoreValue(val: unknown, forceTimestamp = false): FirestoreValue {
  if (val === null || val === undefined) {
    return { nullValue: null };
  }
  if (val instanceof Date) {
    return { timestampValue: val.toISOString() };
  }
  if (forceTimestamp && typeof val === 'string') {
    return { timestampValue: val };
  }
  if (typeof val === 'boolean') {
    return { booleanValue: val };
  }
  if (typeof val === 'number') {
    if (Number.isInteger(val)) {
      return { integerValue: String(val) };
    }
    return { doubleValue: val };
  }
  return { stringValue: String(val) };
}

export function decodeDocument<T extends Record<string, unknown>>(raw: FirestoreDocumentRaw): T & { _id: string } {
  const segments = raw.name.split('/');
  const _id = segments[segments.length - 1] ?? '';
  const result: Record<string, unknown> = { _id };
  if (raw.fields) {
    for (const [key, value] of Object.entries(raw.fields)) {
      result[key] = fromFirestoreValue(value);
    }
  }
  return result as T & { _id: string };
}

export async function getFirestoreDoc<T extends Record<string, unknown>>(
  config: FirestoreConfigRef,
  docPath: string,
  idToken: string
): Promise<(T & { _id: string }) | null> {
  const url = `${getBaseUrl(config)}/${docPath}`;
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${idToken}`,
    },
  });
  if (res.status === 404) {
    return null;
  }
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Firestore GET ${docPath} failed (${res.status}): ${body}`);
  }
  const raw = (await res.json()) as FirestoreDocumentRaw;
  return decodeDocument<T>(raw);
}

export async function listFirestoreCollection<T extends Record<string, unknown>>(
  config: FirestoreConfigRef,
  collectionPath: string,
  idToken?: string,
  pageSize = 200
): Promise<Array<T & { _id: string }>> {
  const url = `${getBaseUrl(config)}/${collectionPath}?pageSize=${pageSize}`;
  const headers: Record<string, string> = {};
  if (idToken) {
    headers.Authorization = `Bearer ${idToken}`;
  }
  const res = await fetch(url, { headers });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Firestore LIST ${collectionPath} failed (${res.status}): ${body}`);
  }
  const data = (await res.json()) as { documents?: FirestoreDocumentRaw[] };
  return (data.documents ?? []).map((doc) => decodeDocument<T>(doc));
}

export async function commitServerTimestampDoc(
  config: FirestoreConfigRef,
  params: {
    docPath: string;
    fields: Record<string, { value: unknown; isTimestamp?: boolean }>;
    updateMaskFields?: string[];
    idToken: string;
    serverTimestampFields?: string[];
    existsPrecondition?: boolean;
  }
): Promise<void> {
  const dbId = config.firestoreDatabaseId || '(default)';
  const fullDocName = `projects/${config.projectId}/databases/${dbId}/documents/${params.docPath}`;
  const commitUrl = `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(config.projectId)}/databases/${encodeURIComponent(dbId)}/documents:commit`;

  const encodedFields: Record<string, FirestoreValue> = {};
  for (const [k, spec] of Object.entries(params.fields)) {
    encodedFields[k] = toFirestoreValue(spec.value, spec.isTimestamp);
  }

  const write: Record<string, unknown> = {
    update: {
      name: fullDocName,
      fields: encodedFields,
    },
  };

  if (params.updateMaskFields && params.updateMaskFields.length > 0) {
    write.updateMask = { fieldPaths: params.updateMaskFields };
  }

  if (params.existsPrecondition !== undefined) {
    write.currentDocument = { exists: params.existsPrecondition };
  }

  if (params.serverTimestampFields && params.serverTimestampFields.length > 0) {
    write.updateTransforms = params.serverTimestampFields.map((fieldPath) => ({
      fieldPath,
      setToServerValue: 'REQUEST_TIME',
    }));
  }

  const res = await fetch(commitUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${params.idToken}`,
    },
    body: JSON.stringify({ writes: [write] }),
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Firestore COMMIT ${params.docPath} failed (${res.status}): ${body}`);
  }
}

export async function deleteFirestoreDoc(
  config: FirestoreConfigRef,
  docPath: string,
  idToken: string
): Promise<void> {
  const url = `${getBaseUrl(config)}/${docPath}`;
  const res = await fetch(url, {
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${idToken}`,
    },
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Firestore DELETE ${docPath} failed (${res.status}): ${body}`);
  }
}
