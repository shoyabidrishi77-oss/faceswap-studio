import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computeRazorpaySignature,
  formatRazorpayApiError,
  getRazorpayConfigStatus,
  getServerServicePlan,
  verifyRazorpaySignature,
  verifyRazorpayWebhookSignature,
} from './razorpay';

test('resolves authoritative server-side plan pricing in INR', () => {
  assert.equal(getServerServicePlan('shorts-basic-claim')?.priceInr, 149);
  assert.equal(getServerServicePlan('reels-audio-unblock')?.priceInr, 399);
  assert.equal(getServerServicePlan('yt-content-id')?.priceInr, 499);
  assert.equal(getServerServicePlan('copyright-strike')?.priceInr, 1499);
  assert.equal(getServerServicePlan('channel-cleanup-pack')?.priceInr, 1999);
  assert.equal(getServerServicePlan('tampered-plan'), null);
});

test('detects Razorpay gateway configuration without exposing secret key', () => {
  const unconfigured = getRazorpayConfigStatus({});
  assert.deepEqual(unconfigured, {
    configured: false,
    mode: 'unconfigured',
    keyId: null,
  });

  const partial = getRazorpayConfigStatus({ RAZORPAY_KEY_ID: 'rzp_test_12345' });
  assert.equal(partial.configured, false);
  assert.equal(partial.keyId, null);

  const testMode = getRazorpayConfigStatus({
    RAZORPAY_KEY_ID: 'rzp_test_abc123',
    RAZORPAY_KEY_SECRET: 'super_secret_value',
  });
  assert.deepEqual(testMode, {
    configured: true,
    mode: 'test',
    keyId: 'rzp_test_abc123',
  });
  assert.equal('keySecret' in testMode, false);

  const liveMode = getRazorpayConfigStatus({
    RAZORPAY_KEY_ID: 'rzp_live_xyz999',
    RAZORPAY_KEY_SECRET: 'live_secret',
  });
  assert.equal(liveMode.configured, true);
  assert.equal(liveMode.mode, 'live');

  const viteFallbackMode = getRazorpayConfigStatus({
    VITE_RAZORPAY_KEY_ID: 'rzp_test_vite123',
    RAZORPAY_KEY_SECRET: 'test_secret',
  });
  assert.deepEqual(viteFallbackMode, {
    configured: true,
    mode: 'test',
    keyId: 'rzp_test_vite123',
  });
});

test('verifies Razorpay payment HMAC-SHA256 signatures and rejects tampered payloads', () => {
  const secret = 'test_webhook_secret_key';
  const orderId = 'order_Q1A2B3C4D5E6';
  const paymentId = 'pay_Z9Y8X7W6V5U4';
  const validSignature = computeRazorpaySignature({ orderId, paymentId, secret });

  assert.equal(
    verifyRazorpaySignature({
      orderId,
      paymentId,
      signature: validSignature,
      secret,
    }),
    true
  );

  assert.equal(
    verifyRazorpaySignature({
      orderId: 'order_TAMPERED',
      paymentId,
      signature: validSignature,
      secret,
    }),
    false
  );

  assert.equal(
    verifyRazorpaySignature({
      orderId,
      paymentId,
      signature: validSignature.replace(/^./, validSignature[0] === 'a' ? 'b' : 'a'),
      secret,
    }),
    false
  );

  assert.equal(
    verifyRazorpaySignature({
      orderId,
      paymentId,
      signature: 'short',
      secret,
    }),
    false
  );
});

test('verifies Razorpay webhook payload signatures', () => {
  const rawBody = JSON.stringify({ event: 'payment.captured', payload: { id: 'pay_123' } });
  const secret = 'whsec_test';
  const sig = computeRazorpaySignature({
    orderId: 'unused',
    paymentId: 'unused',
    secret,
  });

  // Ensure mismatched signature fails cleanly
  assert.equal(verifyRazorpayWebhookSignature({ rawBody, signature: sig, secret }), false);
});

test('formats Razorpay API errors into readable messages without raw JSON dumps', () => {
  const authErr = formatRazorpayApiError(
    401,
    JSON.stringify({ error: { description: 'Authentication failed', code: 'BAD_REQUEST_ERROR' } })
  );
  assert.match(authErr, /Razorpay authentication failed/i);
  assert.equal(authErr.includes('{'), false);

  const badReq = formatRazorpayApiError(
    400,
    JSON.stringify({ error: { description: 'Amount exceeds maximum allowed' } })
  );
  assert.equal(badReq, 'Razorpay order creation failed: Amount exceeds maximum allowed');
});
