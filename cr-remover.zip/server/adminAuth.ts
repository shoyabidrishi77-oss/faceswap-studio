import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export interface FirebaseAppletConfig {
  projectId: string;
  appId: string;
  apiKey: string;
  authDomain: string;
  firestoreDatabaseId: string;
  storageBucket: string;
  messagingSenderId: string;
}

export interface VerifiedFirebaseToken {
  uid: string;
  email: string;
  emailVerified: boolean;
  name: string;
  picture?: string;
  authTime: number;
  expiresAt: number;
  rawClaims: Record<string, unknown>;
}

export interface AdminAuthorizationResult {
  authorized: boolean;
  reason?: string;
  role?: 'super_admin' | 'admin';
}

const GOOGLE_CERTS_URL =
  'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';

const DEFAULT_BOOTSTRAPPED_ADMIN = 'shoyabidrishi77@gmail.com';

let cachedCerts: { certs: Record<string, string>; expiresAtMs: number } | null = null;

export function loadFirebaseAppletConfig(rootDir = process.cwd()): FirebaseAppletConfig {
  const configPath = path.resolve(rootDir, 'firebase-applet-config.json');
  const raw = fs.readFileSync(configPath, 'utf8');
  return JSON.parse(raw) as FirebaseAppletConfig;
}

export function parseAllowedAdminEmails(envValue?: string): string[] {
  const source = envValue && envValue.trim().length > 0 ? envValue : DEFAULT_BOOTSTRAPPED_ADMIN;
  return Array.from(
    new Set(
      source
        .split(',')
        .map((item) => item.trim().toLowerCase())
        .filter((item) => item.length > 0)
    )
  );
}

export function isValidFirebaseUid(uid: string): boolean {
  return typeof uid === 'string' && uid.length >= 1 && uid.length <= 128 && /^[a-zA-Z0-9_\-]+$/.test(uid);
}

function decodeBase64Url(segment: string): Buffer {
  const normalized = segment.replace(/-/g, '+').replace(/_/g, '/');
  const padLen = (4 - (normalized.length % 4)) % 4;
  return Buffer.from(normalized + '='.repeat(padLen), 'base64');
}

function parseMaxAgeSeconds(cacheControl: string | null): number {
  if (!cacheControl) return 300;
  const match = /max-age=(\d+)/i.exec(cacheControl);
  if (!match) return 300;
  const parsed = Number.parseInt(match[1], 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 300;
}

export async function fetchFirebasePublicCerts(): Promise<Record<string, string>> {
  const now = Date.now();
  if (cachedCerts && now < cachedCerts.expiresAtMs) {
    return cachedCerts.certs;
  }

  const response = await fetch(GOOGLE_CERTS_URL);
  if (!response.ok) {
    throw new Error(`Failed to fetch Firebase public certificates (${response.status})`);
  }
  const certs = (await response.json()) as Record<string, string>;
  const maxAge = parseMaxAgeSeconds(response.headers.get('cache-control'));
  cachedCerts = {
    certs,
    expiresAtMs: now + maxAge * 1000,
  };
  return certs;
}

export function verifyFirebaseIdTokenWithCerts(
  idToken: string,
  projectId: string,
  certs: Record<string, string>,
  nowEpochSeconds = Math.floor(Date.now() / 1000)
): VerifiedFirebaseToken {
  if (!idToken || typeof idToken !== 'string') {
    throw new Error('Missing Firebase ID token.');
  }
  const parts = idToken.split('.');
  if (parts.length !== 3) {
    throw new Error('Malformed Firebase ID token.');
  }

  const [headerB64, payloadB64, signatureB64] = parts;
  let header: { alg?: string; kid?: string; typ?: string };
  let payload: Record<string, unknown>;
  try {
    header = JSON.parse(decodeBase64Url(headerB64).toString('utf8')) as {
      alg?: string;
      kid?: string;
      typ?: string;
    };
    payload = JSON.parse(decodeBase64Url(payloadB64).toString('utf8')) as Record<string, unknown>;
  } catch {
    throw new Error('Invalid token encoding.');
  }

  if (header.alg !== 'RS256') {
    throw new Error('Unsupported token algorithm.');
  }
  if (!header.kid || !certs[header.kid]) {
    throw new Error('Unknown signing key ID.');
  }

  const signingInput = `${headerB64}.${payloadB64}`;
  const signature = decodeBase64Url(signatureB64);
  const verifier = crypto.createVerify('RSA-SHA256');
  verifier.update(signingInput);
  verifier.end();

  const signatureValid = verifier.verify(certs[header.kid], signature);
  if (!signatureValid) {
    throw new Error('Invalid Firebase ID token signature.');
  }

  const expectedIssuer = `https://securetoken.google.com/${projectId}`;
  const iss = typeof payload.iss === 'string' ? payload.iss : '';
  const aud = typeof payload.aud === 'string' ? payload.aud : '';
  const sub = typeof payload.sub === 'string' ? payload.sub : '';
  const exp = typeof payload.exp === 'number' ? payload.exp : 0;
  const iat = typeof payload.iat === 'number' ? payload.iat : 0;
  const authTime = typeof payload.auth_time === 'number' ? payload.auth_time : 0;
  const email = typeof payload.email === 'string' ? payload.email.trim().toLowerCase() : '';
  const emailVerified = payload.email_verified === true;
  const name = typeof payload.name === 'string' && payload.name.trim() ? payload.name.trim() : email;
  const picture = typeof payload.picture === 'string' ? payload.picture : undefined;

  if (aud !== projectId) {
    throw new Error('Token audience does not match Firebase project.');
  }
  if (iss !== expectedIssuer) {
    throw new Error('Token issuer does not match Firebase project.');
  }
  if (!isValidFirebaseUid(sub)) {
    throw new Error('Invalid token subject.');
  }
  if (exp <= nowEpochSeconds) {
    throw new Error('Firebase ID token has expired.');
  }
  if (iat > nowEpochSeconds + 300) {
    throw new Error('Token issued-at timestamp is invalid.');
  }
  if (authTime <= 0 || authTime > nowEpochSeconds + 300) {
    throw new Error('Token auth_time timestamp is invalid.');
  }
  if (!email || !emailVerified) {
    throw new Error('Verified administrator email is required.');
  }

  return {
    uid: sub,
    email,
    emailVerified,
    name,
    picture,
    authTime,
    expiresAt: exp,
    rawClaims: payload,
  };
}

export function evaluateAdminAuthorization(params: {
  token: VerifiedFirebaseToken;
  allowedEmails: string[];
  firestoreAdminRecord?: { active?: boolean; role?: string } | null;
}): AdminAuthorizationResult {
  if (!params.token.emailVerified) {
    return { authorized: false, reason: 'Email address is not verified.' };
  }

  if (params.allowedEmails.includes(params.token.email.toLowerCase())) {
    return { authorized: true, role: 'super_admin' };
  }

  if (params.firestoreAdminRecord && params.firestoreAdminRecord.active === true) {
    const role = params.firestoreAdminRecord.role === 'super_admin' ? 'super_admin' : 'admin';
    return { authorized: true, role };
  }

  return {
    authorized: false,
    reason: 'Authenticated account is not authorized as an administrator.',
  };
}

export function extractBearerToken(authorizationHeader?: string): string | null {
  if (!authorizationHeader) return null;
  const match = /^Bearer\s+(.+)$/i.exec(authorizationHeader.trim());
  return match ? match[1].trim() : null;
}
