import crypto from 'node:crypto';

export interface ServerServicePlan {
  id: string;
  title: string;
  priceInr: number;
}

export const SERVER_SERVICE_PLANS: Record<string, ServerServicePlan> = {
  'shorts-basic-claim': {
    id: 'shorts-basic-claim',
    title: 'Shorts & Single Clip Claim',
    priceInr: 149,
  },
  'reels-audio-unblock': {
    id: 'reels-audio-unblock',
    title: 'Instagram Reels Audio Unblock',
    priceInr: 399,
  },
  'yt-content-id': {
    id: 'yt-content-id',
    title: 'YouTube Content ID Claim',
    priceInr: 499,
  },
  'copyright-strike': {
    id: 'copyright-strike',
    title: 'Copyright Strike Retraction',
    priceInr: 1499,
  },
  'channel-cleanup-pack': {
    id: 'channel-cleanup-pack',
    title: 'Channel Clean-Up Pack',
    priceInr: 1999,
  },
};

export interface RazorpayGatewayStatus {
  configured: boolean;
  mode: 'live' | 'test' | 'unconfigured';
  keyId: string | null;
}

export function getServerServicePlan(serviceId: string): ServerServicePlan | null {
  if (!serviceId || typeof serviceId !== 'string') return null;
  return SERVER_SERVICE_PLANS[serviceId.trim()] ?? null;
}

export function getRazorpayConfigStatus(
  env: Record<string, string | undefined> = process.env
): RazorpayGatewayStatus {
  const keyId = env.RAZORPAY_KEY_ID?.trim() || env.VITE_RAZORPAY_KEY_ID?.trim() || '';
  const keySecret = env.RAZORPAY_KEY_SECRET?.trim() || '';

  if (!keyId || !keySecret) {
    return {
      configured: false,
      mode: 'unconfigured',
      keyId: null,
    };
  }

  const mode: RazorpayGatewayStatus['mode'] = keyId.startsWith('rzp_live_') ? 'live' : 'test';
  return {
    configured: true,
    mode,
    keyId,
  };
}

export function computeRazorpaySignature(params: {
  orderId: string;
  paymentId: string;
  secret: string;
}): string {
  return crypto
    .createHmac('sha256', params.secret)
    .update(`${params.orderId}|${params.paymentId}`)
    .digest('hex');
}

export function verifyRazorpaySignature(params: {
  orderId: string;
  paymentId: string;
  signature: string;
  secret: string;
}): boolean {
  const orderId = params.orderId.trim();
  const paymentId = params.paymentId.trim();
  const signature = params.signature.trim();
  const secret = params.secret.trim();

  if (!orderId || !paymentId || !signature || !secret) {
    return false;
  }

  const expected = computeRazorpaySignature({ orderId, paymentId, secret });
  const expectedBuf = Buffer.from(expected, 'utf8');
  const providedBuf = Buffer.from(signature, 'utf8');
  if (expectedBuf.length !== providedBuf.length) {
    return false;
  }
  return crypto.timingSafeEqual(expectedBuf, providedBuf);
}

export function verifyRazorpayWebhookSignature(params: {
  rawBody: string;
  signature: string;
  secret: string;
}): boolean {
  if (!params.rawBody || !params.signature.trim() || !params.secret.trim()) {
    return false;
  }
  const expected = crypto
    .createHmac('sha256', params.secret.trim())
    .update(params.rawBody)
    .digest('hex');
  const expectedBuf = Buffer.from(expected, 'utf8');
  const providedBuf = Buffer.from(params.signature.trim(), 'utf8');
  if (expectedBuf.length !== providedBuf.length) {
    return false;
  }
  return crypto.timingSafeEqual(expectedBuf, providedBuf);
}

export interface RazorpayOrderApiResponse {
  id: string;
  entity: string;
  amount: number;
  amount_paid: number;
  amount_due: number;
  currency: string;
  receipt: string;
  status: string;
}

export function formatRazorpayApiError(status: number, errText: string): string {
  let description = '';
  try {
    const parsed = JSON.parse(errText) as { error?: { description?: string } };
    description = parsed?.error?.description?.trim() ?? '';
  } catch {
    description = errText.trim();
  }

  if (status === 401) {
    return 'Razorpay authentication failed. Verify that RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET in your environment secrets are a valid matching key pair.';
  }
  return description
    ? `Razorpay order creation failed: ${description}`
    : `Razorpay order creation failed (HTTP ${status}).`;
}

export async function createRazorpayOrderOnApi(params: {
  keyId: string;
  keySecret: string;
  amountInr: number;
  receipt: string;
  notes?: Record<string, string>;
}): Promise<RazorpayOrderApiResponse> {
  const amountPaise = Math.round(params.amountInr * 100);
  if (!Number.isFinite(amountPaise) || amountPaise < 100) {
    throw new Error('Order amount must be at least ₹1 (100 paise).');
  }

  const basicAuth = Buffer.from(`${params.keyId}:${params.keySecret}`).toString('base64');
  const response = await fetch('https://api.razorpay.com/v1/orders', {
    method: 'POST',
    headers: {
      Authorization: `Basic ${basicAuth}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      amount: amountPaise,
      currency: 'INR',
      receipt: params.receipt.slice(0, 40),
      notes: params.notes ?? {},
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(formatRazorpayApiError(response.status, errText));
  }

  return (await response.json()) as RazorpayOrderApiResponse;
}
