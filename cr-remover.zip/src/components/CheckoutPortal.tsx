import { FormEvent, useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import {
  AlertCircle,
  CheckCircle2,
  Copy,
  CreditCard,
  Download,
  Lock,
  Maximize2,
  QrCode,
  ShieldCheck,
  X,
} from 'lucide-react';
import {
  CaseOrder,
  CaseValidationErrors,
  PLATFORMS,
  PlatformType,
  QR_IMAGE_PATH,
  SERVICE_PLANS,
  UPI_APPS,
  UpiAppId,
  buildUpiIntentPayload,
  buildUpiReferenceText,
  formatInr,
  getPaymentAppLabel,
  getServiceById,
  getStatusLabel,
  validateCaseInput,
  validateUtrNumber,
} from '../utils/paymentLogic';
import {
  RazorpayPublicConfig,
  fetchRazorpayPublicConfig,
  initiateRazorpayCheckout,
} from '../utils/razorpayClient';
import { UpiQrCard } from './UpiQrCard';

interface CheckoutPortalProps {
  selectedServiceId: string;
  onChangeServiceId: (serviceId: string) => void;
  activeOrder: CaseOrder | null;
  onCreateOrder: (input: {
    serviceId: string;
    platform: PlatformType;
    videoUrl: string;
    claimantName: string;
    creatorName: string;
    contact: string;
  }) => CaseOrder;
  onConfirmPayment: (caseId: string, app: UpiAppId, utr: string) => CaseOrder;
  onConfirmRazorpayPayment: (
    caseId: string,
    details: { razorpayOrderId: string; razorpayPaymentId: string; paidAtIso?: string }
  ) => CaseOrder;
  onResetActiveOrder: () => void;
  onInspectInTracker: (caseId: string) => void;
}

function UpiAppGlyph({ appId }: { appId: UpiAppId }) {
  if (appId === 'phonepe') {
    return (
      <span
        aria-hidden="true"
        className="w-7 h-7 rounded-md bg-[#5F259F] text-white text-xs font-bold flex items-center justify-center shrink-0"
      >
        Pe
      </span>
    );
  }
  if (appId === 'gpay') {
    return (
      <span
        aria-hidden="true"
        className="w-7 h-7 rounded-md bg-[#1A73E8] text-white text-xs font-bold flex items-center justify-center shrink-0"
      >
        G
      </span>
    );
  }
  if (appId === 'paytm') {
    return (
      <span
        aria-hidden="true"
        className="w-7 h-7 rounded-md bg-[#002E6E] text-[#00BAF2] text-[10px] font-extrabold flex items-center justify-center shrink-0 tracking-tight"
      >
        Pay
      </span>
    );
  }
  return (
    <span
      aria-hidden="true"
      className="w-7 h-7 rounded-md bg-slate-800 text-white flex items-center justify-center shrink-0"
    >
      <QrCode className="w-4 h-4" />
    </span>
  );
}

export function CheckoutPortal({
  selectedServiceId,
  onChangeServiceId,
  activeOrder,
  onCreateOrder,
  onConfirmPayment,
  onConfirmRazorpayPayment,
  onResetActiveOrder,
  onInspectInTracker,
}: CheckoutPortalProps) {
  const [platform, setPlatform] = useState<PlatformType>('YouTube');
  const [videoUrl, setVideoUrl] = useState('');
  const [claimantName, setClaimantName] = useState('');
  const [creatorName, setCreatorName] = useState('');
  const [contact, setContact] = useState('');
  const [formErrors, setFormErrors] = useState<CaseValidationErrors>({});

  const [gatewayTab, setGatewayTab] = useState<'upi' | 'razorpay'>('upi');
  const [selectedApp, setSelectedApp] = useState<UpiAppId>('phonepe');
  const [utrInput, setUtrInput] = useState('');
  const [utrError, setUtrError] = useState<string | null>(null);
  const [copiedNotice, setCopiedNotice] = useState(false);
  const [qrZoomOpen, setQrZoomOpen] = useState(false);

  const [razorpayConfig, setRazorpayConfig] = useState<RazorpayPublicConfig | null>(null);
  const [razorpayLoading, setRazorpayLoading] = useState(false);
  const [razorpayError, setRazorpayError] = useState<string | null>(null);

  const utrInputRef = useRef<HTMLInputElement>(null);

  const currentPlan = getServiceById(selectedServiceId) ?? SERVICE_PLANS[0];
  const displayAmount = activeOrder ? activeOrder.amountInr : currentPlan.priceInr;
  const activeAppMeta = UPI_APPS.find((a) => a.id === selectedApp) ?? UPI_APPS[0];
  const upiPayload = buildUpiIntentPayload({
    amountInr: displayAmount,
    caseId: activeOrder?.caseId,
    serviceTitle: activeOrder?.serviceTitle ?? currentPlan.title,
  });

  useEffect(() => {
    let mounted = true;
    fetchRazorpayPublicConfig()
      .then((cfg) => {
        if (mounted) setRazorpayConfig(cfg);
      })
      .catch(() => {
        if (mounted) {
          setRazorpayConfig({ configured: false, mode: 'unconfigured', keyId: null });
        }
      });
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (activeOrder && activeOrder.status === 'awaiting_payment') {
      setUtrError(null);
      setRazorpayError(null);
    }
  }, [activeOrder]);

  function handleCreateCaseSubmit(e: FormEvent) {
    e.preventDefault();
    const errors = validateCaseInput({
      serviceId: selectedServiceId,
      platform,
      videoUrl,
      claimantName,
      creatorName,
      contact,
    });
    setFormErrors(errors);
    if (Object.keys(errors).length > 0) {
      return;
    }

    onCreateOrder({
      serviceId: selectedServiceId,
      platform,
      videoUrl,
      claimantName,
      creatorName,
      contact,
    });
    setUtrError(null);
    setTimeout(() => {
      utrInputRef.current?.focus();
    }, 60);
  }

  function handleConfirmUtrSubmit(e: FormEvent) {
    e.preventDefault();
    if (!activeOrder) {
      setUtrError('Submit Step 1 (Claim Details) first to generate your Case ID before confirming payment.');
      return;
    }
    const check = validateUtrNumber(utrInput);
    if (!check.valid) {
      setUtrError(check.error ?? 'Invalid 12-digit UTR number.');
      return;
    }
    setUtrError(null);
    onConfirmPayment(activeOrder.caseId, selectedApp, check.normalized);
    setUtrInput('');
  }

  async function handleRazorpayPayClick() {
    if (!activeOrder) {
      setRazorpayError('Submit Step 1 (Claim Details) first to generate your Case ID before paying via Razorpay.');
      return;
    }
    setRazorpayError(null);
    setRazorpayLoading(true);
    try {
      const verified = await initiateRazorpayCheckout({
        caseId: activeOrder.caseId,
        serviceId: activeOrder.serviceId,
        platform: activeOrder.platform,
        creatorName: activeOrder.creatorName,
        contact: activeOrder.contact,
      });
      onConfirmRazorpayPayment(activeOrder.caseId, {
        razorpayOrderId: verified.razorpayOrderId,
        razorpayPaymentId: verified.razorpayPaymentId,
        paidAtIso: verified.paidAt,
      });
    } catch (err) {
      setRazorpayError(
        err instanceof Error ? err.message : 'Unable to complete Razorpay payment.'
      );
    } finally {
      setRazorpayLoading(false);
    }
  }

  async function handleCopySummary() {
    const text = activeOrder
      ? buildUpiReferenceText(activeOrder)
      : `${currentPlan.title} | ${formatInr(currentPlan.priceInr)}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopiedNotice(true);
      setTimeout(() => setCopiedNotice(false), 2000);
    } catch {
      setCopiedNotice(false);
    }
  }

  async function handleDownloadQr() {
    try {
      const response = await fetch(QR_IMAGE_PATH);
      if (response.ok && response.headers.get('content-type')?.startsWith('image/')) {
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'cr-remover-upi-qr.png';
        link.click();
        URL.revokeObjectURL(url);
        return;
      }
    } catch {
      // Fallback to generated QR PNG below
    }

    const dataUrl = await QRCode.toDataURL(upiPayload, {
      errorCorrectionLevel: 'H',
      margin: 2,
      width: 512,
    });
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = 'cr-remover-upi-qr.png';
    link.click();
  }

  function handleStartFresh() {
    onResetActiveOrder();
    setVideoUrl('');
    setClaimantName('');
    setCreatorName('');
    setContact('');
    setFormErrors({});
    setUtrInput('');
    setUtrError(null);
  }

  const isPaidOrder = activeOrder && activeOrder.status !== 'awaiting_payment';

  return (
    <section id="checkout" className="scroll-mt-16 py-16 sm:py-20 bg-[#F8FAFC] border-b border-slate-200/80">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-10">
          <p className="text-sm font-medium text-slate-500 mb-2">
            Online Case Desk · Instant UPI Checkout
          </p>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
            Submit claim &amp; pay via QR, Google Pay, Paytm, or PhonePe
          </h2>
          <p className="mt-3 text-base text-slate-600 leading-relaxed">
            Fill in your video link to lock a Case ID, scan the verified CR Remover UPI QR code
            using any UPI app, and confirm your 12-digit UTR reference.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Step 1: Claim Intake Form */}
          <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-6 sm:p-7">
            <div className="flex items-baseline justify-between gap-4 pb-4 mb-6 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-950">01. Claim Details</h3>
                <p className="text-sm text-slate-500 mt-0.5">
                  {activeOrder
                    ? `Active Case ${activeOrder.caseId}`
                    : 'Generates your Case ID for payment'}
                </p>
              </div>
              <span className="text-base font-bold text-[#1E40AF] font-mono tabular-nums">
                {formatInr(currentPlan.priceInr)}
              </span>
            </div>

            <form onSubmit={handleCreateCaseSubmit} noValidate className="space-y-4">
              <div>
                <label
                  htmlFor="claim-service"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Removal Service
                </label>
                <select
                  id="claim-service"
                  value={selectedServiceId}
                  disabled={Boolean(activeOrder)}
                  onChange={(e) => onChangeServiceId(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF] focus:ring-2 focus:ring-[#1E40AF]/15 disabled:bg-slate-50 disabled:text-slate-600"
                >
                  {SERVICE_PLANS.map((plan) => (
                    <option key={plan.id} value={plan.id}>
                      {plan.title} — {formatInr(plan.priceInr)}
                    </option>
                  ))}
                </select>
                {formErrors.serviceId && (
                  <p role="alert" className="mt-1.5 text-xs font-medium text-red-700">
                    {formErrors.serviceId}
                  </p>
                )}
              </div>

              <div>
                <span className="block text-sm font-medium text-slate-800 mb-1.5">Platform</span>
                <div className="grid grid-cols-2 gap-2">
                  {PLATFORMS.map((item) => {
                    const active = platform === item;
                    return (
                      <button
                        key={item}
                        type="button"
                        disabled={Boolean(activeOrder)}
                        aria-pressed={active}
                        onClick={() => setPlatform(item)}
                        className={`px-3 py-2 text-xs sm:text-sm font-medium rounded-lg border transition-colors whitespace-nowrap cursor-pointer disabled:cursor-not-allowed ${
                          active
                            ? 'bg-[#1E40AF] text-white border-[#1E40AF]'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        {item}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label
                  htmlFor="claim-video-url"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Claimed Video or Reel URL
                </label>
                <input
                  id="claim-video-url"
                  type="url"
                  disabled={Boolean(activeOrder)}
                  value={videoUrl}
                  onChange={(e) => setVideoUrl(e.target.value)}
                  placeholder="https://www.youtube.com/watch?v=..."
                  aria-invalid={Boolean(formErrors.videoUrl)}
                  className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg placeholder:text-slate-400 focus:outline-none focus:border-[#1E40AF] focus:ring-2 focus:ring-[#1E40AF]/15 disabled:bg-slate-50"
                />
                {formErrors.videoUrl && (
                  <p role="alert" className="mt-1.5 text-xs font-medium text-red-700">
                    {formErrors.videoUrl}
                  </p>
                )}
              </div>

              <div>
                <label
                  htmlFor="claim-claimant"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Claimant / Music Label Name (optional)
                </label>
                <input
                  id="claim-claimant"
                  type="text"
                  disabled={Boolean(activeOrder)}
                  value={claimantName}
                  onChange={(e) => setClaimantName(e.target.value)}
                  placeholder="e.g. T-Series / Audio Network / Unknown"
                  className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg placeholder:text-slate-400 focus:outline-none focus:border-[#1E40AF] focus:ring-2 focus:ring-[#1E40AF]/15 disabled:bg-slate-50"
                />
              </div>

              <div>
                <label
                  htmlFor="claim-creator-name"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Your Name or Channel Name
                </label>
                <input
                  id="claim-creator-name"
                  type="text"
                  disabled={Boolean(activeOrder)}
                  value={creatorName}
                  onChange={(e) => setCreatorName(e.target.value)}
                  placeholder="e.g. Rohan Verma / TechVibe India"
                  aria-invalid={Boolean(formErrors.creatorName)}
                  className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg placeholder:text-slate-400 focus:outline-none focus:border-[#1E40AF] focus:ring-2 focus:ring-[#1E40AF]/15 disabled:bg-slate-50"
                />
                {formErrors.creatorName && (
                  <p role="alert" className="mt-1.5 text-xs font-medium text-red-700">
                    {formErrors.creatorName}
                  </p>
                )}
              </div>

              <div>
                <label
                  htmlFor="claim-contact"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  WhatsApp Number or Email
                </label>
                <input
                  id="claim-contact"
                  type="text"
                  disabled={Boolean(activeOrder)}
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  placeholder="+91 98765 43210 or name@domain.com"
                  aria-invalid={Boolean(formErrors.contact)}
                  className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg placeholder:text-slate-400 focus:outline-none focus:border-[#1E40AF] focus:ring-2 focus:ring-[#1E40AF]/15 disabled:bg-slate-50"
                />
                {formErrors.contact && (
                  <p role="alert" className="mt-1.5 text-xs font-medium text-red-700">
                    {formErrors.contact}
                  </p>
                )}
              </div>

              {!activeOrder ? (
                <button
                  type="submit"
                  className="w-full py-3 px-4 text-sm font-semibold text-white bg-slate-950 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-950"
                >
                  Generate Case ID &amp; Proceed to Payment
                </button>
              ) : (
                <div className="pt-2 flex items-center justify-between gap-3">
                  <span className="text-sm font-medium text-slate-700 font-mono tabular-nums">
                    Case Locked: {activeOrder.caseId}
                  </span>
                  <button
                    type="button"
                    onClick={handleStartFresh}
                    className="text-sm font-semibold text-[#1E40AF] hover:underline underline-offset-4 cursor-pointer"
                  >
                    New / Edit Claim
                  </button>
                </div>
              )}
            </form>
          </div>

          {/* Step 2: Online UPI Payment System (QR + Google Pay + Paytm + PhonePe) */}
          <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-6 sm:p-7">
            {isPaidOrder ? (
              <div data-testid="payment-receipt" className="space-y-6">
                <div className="flex items-start gap-3.5 pb-5 border-b border-slate-200">
                  <CheckCircle2 className="w-7 h-7 text-emerald-700 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold text-emerald-800">
                      {activeOrder.paymentMethod === 'razorpay'
                        ? 'Razorpay Payment Verified'
                        : 'Payment Proof Recorded'}{' '}
                      · {getStatusLabel(activeOrder.status)}
                    </p>
                    <h3 className="text-2xl font-bold text-slate-950 mt-1">
                      Case {activeOrder.caseId} Confirmed
                    </h3>
                    <p className="text-sm text-slate-600 mt-1">
                      {activeOrder.paymentMethod === 'razorpay'
                        ? `Your Razorpay payment (${activeOrder.razorpayPaymentId}) has been verified and attached to your claim file. Updates will be sent to ${activeOrder.contact}.`
                        : `Your UPI transaction reference has been attached to your claim file. Updates will be sent to ${activeOrder.contact}.`}
                    </p>
                  </div>
                </div>

                <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-[#F8FAFC] rounded-lg p-5">
                  <div>
                    <dt className="text-xs font-medium text-slate-500">Case ID</dt>
                    <dd className="mt-1 text-sm font-bold text-slate-950 font-mono tabular-nums">
                      {activeOrder.caseId}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs font-medium text-slate-500">Amount Paid</dt>
                    <dd className="mt-1 text-sm font-bold text-slate-950 font-mono tabular-nums">
                      {formatInr(activeOrder.amountInr)}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs font-medium text-slate-500">
                      {activeOrder.paymentMethod === 'razorpay' ? 'Payment Gateway' : 'UPI App Used'}
                    </dt>
                    <dd className="mt-1 text-sm font-semibold text-slate-900">
                      {activeOrder.paymentMethod === 'razorpay'
                        ? 'Razorpay Gateway'
                        : getPaymentAppLabel(activeOrder.paymentApp)}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs font-medium text-slate-500">
                      {activeOrder.paymentMethod === 'razorpay'
                        ? 'Razorpay Payment ID'
                        : '12-Digit UTR Reference'}
                    </dt>
                    <dd className="mt-1 text-sm font-bold text-slate-950 font-mono tabular-nums break-all">
                      {activeOrder.paymentMethod === 'razorpay'
                        ? activeOrder.razorpayPaymentId
                        : activeOrder.utrNumber}
                    </dd>
                  </div>
                  <div className="sm:col-span-2">
                    <dt className="text-xs font-medium text-slate-500">Service &amp; Platform</dt>
                    <dd className="mt-1 text-sm font-medium text-slate-900">
                      {activeOrder.serviceTitle} · {activeOrder.platform}
                    </dd>
                  </div>
                  <div className="sm:col-span-2">
                    <dt className="text-xs font-medium text-slate-500">Claimed Video URL</dt>
                    <dd className="mt-1 text-sm text-slate-700 break-all">{activeOrder.videoUrl}</dd>
                  </div>
                </dl>

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    onClick={() => onInspectInTracker(activeOrder.caseId)}
                    className="px-5 py-2.5 text-sm font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] rounded-lg transition-colors cursor-pointer"
                  >
                    View in Case Tracker
                  </button>
                  <button
                    type="button"
                    onClick={handleStartFresh}
                    className="px-5 py-2.5 text-sm font-semibold text-slate-800 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
                  >
                    Submit Another Claim
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-start justify-between gap-4 pb-4 mb-5 border-b border-slate-100">
                  <div className="min-w-0 flex-1">
                    <h3 className="text-lg font-bold text-slate-950">
                      02. UPI QR &amp; Razorpay Payment
                    </h3>
                    <p className="text-sm text-slate-500 mt-0.5">
                      {activeOrder
                        ? `Paying for Case ${activeOrder.caseId} · ${activeOrder.serviceTitle}`
                        : `Selected: ${currentPlan.title}`}
                    </p>
                  </div>
                  <div className="flex items-center gap-2.5 shrink-0">
                    <span className="text-xl sm:text-2xl font-bold text-slate-950 font-mono tabular-nums">
                      {formatInr(displayAmount)}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopySummary}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 border border-slate-200 hover:border-slate-300 rounded-md cursor-pointer whitespace-nowrap"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>{copiedNotice ? 'Copied' : 'Copy Ref'}</span>
                    </button>
                  </div>
                </div>

                {/* Payment Gateway Switcher */}
                <div
                  role="tablist"
                  aria-label="Payment Gateway Method"
                  className="grid grid-cols-2 gap-2 p-1 mb-6 bg-slate-100 rounded-lg border border-slate-200/80"
                >
                  <button
                    type="button"
                    role="tab"
                    aria-selected={gatewayTab === 'upi'}
                    onClick={() => setGatewayTab('upi')}
                    className={`flex items-center justify-center gap-2 px-3 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                      gatewayTab === 'upi'
                        ? 'bg-white text-slate-950 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <QrCode className="w-4 h-4 shrink-0" />
                    <span>UPI QR &amp; Apps</span>
                  </button>
                  <button
                    type="button"
                    role="tab"
                    aria-selected={gatewayTab === 'razorpay'}
                    onClick={() => setGatewayTab('razorpay')}
                    className={`flex items-center justify-center gap-2 px-3 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                      gatewayTab === 'razorpay'
                        ? 'bg-white text-slate-950 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 shrink-0" />
                    <span>Razorpay Gateway</span>
                  </button>
                </div>

                {gatewayTab === 'razorpay' ? (
                  <div role="tabpanel" className="space-y-5">
                    <div className="rounded-xl border border-slate-200 bg-[#F8FAFC] p-5 space-y-4">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <div className="text-sm font-bold text-slate-950">
                            Razorpay Online Payment Gateway
                          </div>
                          <p className="text-xs text-slate-600 mt-0.5">
                            Pay via UPI, Debit/Credit Cards, NetBanking, or Wallets with automatic
                            server signature verification.
                          </p>
                        </div>
                        {razorpayConfig && (
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold ${
                              razorpayConfig.configured
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                : 'bg-amber-50 text-amber-800 border border-amber-200'
                            }`}
                          >
                            {razorpayConfig.configured
                              ? razorpayConfig.mode === 'live'
                                ? 'Live Gateway Ready'
                                : 'Test Gateway Ready'
                              : 'Server Keys Required'}
                          </span>
                        )}
                      </div>

                      <dl className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-200/80 text-sm">
                        <div>
                          <dt className="text-xs text-slate-500">Selected Plan</dt>
                          <dd className="font-semibold text-slate-900 mt-0.5">
                            {activeOrder ? activeOrder.serviceTitle : currentPlan.title}
                          </dd>
                        </div>
                        <div>
                          <dt className="text-xs text-slate-500">Case Reference</dt>
                          <dd className="font-mono font-semibold text-slate-900 mt-0.5">
                            {activeOrder ? activeOrder.caseId : 'Submit Step 1 first'}
                          </dd>
                        </div>
                        <div>
                          <dt className="text-xs text-slate-500">Payable Total</dt>
                          <dd className="font-mono font-bold text-[#1E40AF] mt-0.5">
                            {formatInr(displayAmount)}
                          </dd>
                        </div>
                      </dl>
                    </div>

                    {razorpayConfig && !razorpayConfig.configured && (
                      <div
                        role="status"
                        className="rounded-lg border border-amber-200 bg-amber-50/80 p-4 flex items-start gap-3 text-sm text-amber-900"
                      >
                        <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                        <div className="space-y-2">
                          <p className="font-semibold">
                            Razorpay gateway requires server credentials before live checkout can open.
                          </p>
                          <p className="text-xs text-amber-800 leading-relaxed">
                            Add <code className="font-mono font-semibold">RAZORPAY_KEY_ID</code> and{' '}
                            <code className="font-mono font-semibold">RAZORPAY_KEY_SECRET</code> in
                            your AI Studio Secrets or server environment. You can still accept
                            instant payments using the UPI QR &amp; Apps tab.
                          </p>
                          <button
                            type="button"
                            onClick={() => setGatewayTab('upi')}
                            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1E40AF] hover:underline cursor-pointer"
                          >
                            Switch to UPI QR &amp; Apps
                          </button>
                        </div>
                      </div>
                    )}

                    {razorpayError && (
                      <p role="alert" className="text-xs font-medium text-red-700 bg-red-50 border border-red-200 rounded-lg px-3.5 py-2.5">
                        {razorpayError}
                      </p>
                    )}

                    <button
                      type="button"
                      onClick={handleRazorpayPayClick}
                      disabled={razorpayLoading}
                      className="w-full py-3 px-4 inline-flex items-center justify-center gap-2 text-sm font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] disabled:bg-slate-300 disabled:text-slate-600 disabled:cursor-not-allowed rounded-lg transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1E40AF]"
                    >
                      <Lock className="w-4 h-4" />
                      <span>
                        {razorpayLoading
                          ? 'Opening Razorpay Checkout...'
                          : `Pay with Razorpay (${formatInr(displayAmount)})`}
                      </span>
                    </button>

                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <ShieldCheck className="w-4 h-4 text-slate-500 shrink-0" />
                      <span>
                        256-bit SSL secured Razorpay Checkout · Server HMAC-SHA256 verified
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                  {/* Verified QR Card */}
                  <div className="md:col-span-5">
                    <div className="bg-[#1F2024] rounded-xl p-3.5 text-white">
                      <div className="flex items-center justify-between text-xs text-slate-300 mb-2.5 px-1">
                        <span className="font-medium">Scan &amp; Pay UPI QR</span>
                        <span className="font-mono tabular-nums font-semibold text-white">
                          {formatInr(displayAmount)}
                        </span>
                      </div>

                      <UpiQrCard payload={upiPayload} />

                      <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-between gap-2 px-1">
                        <button
                          type="button"
                          onClick={() => setQrZoomOpen(true)}
                          className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-200 hover:text-white cursor-pointer"
                        >
                          <Maximize2 className="w-3.5 h-3.5" />
                          <span>Zoom QR</span>
                        </button>
                        <button
                          type="button"
                          onClick={handleDownloadQr}
                          className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-200 hover:text-white cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Save QR</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* UPI App Selector + Instructions + UTR Verification */}
                  <div className="md:col-span-7 space-y-5">
                    <div>
                      <span className="block text-sm font-medium text-slate-800 mb-2">
                        Choose Your Payment App
                      </span>
                      <div className="grid grid-cols-2 gap-2.5">
                        {UPI_APPS.map((app) => {
                          const isSelected = selectedApp === app.id;
                          return (
                            <button
                              key={app.id}
                              type="button"
                              aria-pressed={isSelected}
                              onClick={() => setSelectedApp(app.id)}
                              className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg border text-left transition-colors cursor-pointer ${
                                isSelected
                                  ? 'border-[#1E40AF] bg-[#1E40AF]/5 text-slate-950'
                                  : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                              }`}
                            >
                              <UpiAppGlyph appId={app.id} />
                              <span className="text-sm font-semibold whitespace-nowrap">
                                {app.label}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="rounded-lg bg-[#F8FAFC] p-4 space-y-2">
                      <div className="text-xs font-semibold text-slate-700">
                        {activeAppMeta.label} Instructions
                      </div>
                      <p className="text-sm text-slate-600 leading-relaxed">
                        {activeAppMeta.stepGuide}
                      </p>
                      <p className="text-xs text-slate-500">{activeAppMeta.utrHint}</p>
                    </div>

                    <form onSubmit={handleConfirmUtrSubmit} noValidate className="space-y-3">
                      <div>
                        <label
                          htmlFor="upi-utr-input"
                          className="block text-sm font-medium text-slate-800 mb-1.5"
                        >
                          12-Digit UPI UTR / Transaction Reference ID
                        </label>
                        <input
                          ref={utrInputRef}
                          id="upi-utr-input"
                          type="text"
                          inputMode="numeric"
                          maxLength={16}
                          value={utrInput}
                          onChange={(e) => setUtrInput(e.target.value)}
                          placeholder="e.g. 631849201458"
                          aria-invalid={Boolean(utrError)}
                          className="w-full px-3.5 py-2.5 text-sm font-mono tabular-nums text-slate-900 bg-white border border-slate-300 rounded-lg placeholder:text-slate-400 focus:outline-none focus:border-[#1E40AF] focus:ring-2 focus:ring-[#1E40AF]/15"
                        />
                        {utrError && (
                          <p role="alert" className="mt-1.5 text-xs font-medium text-red-700">
                            {utrError}
                          </p>
                        )}
                      </div>

                      <button
                        type="submit"
                        className="w-full py-3 px-4 text-sm font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] rounded-lg transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1E40AF]"
                      >
                        Confirm {activeAppMeta.label} Payment ({formatInr(displayAmount)})
                      </button>

                      <div className="flex items-center gap-2 text-xs text-slate-500 pt-1">
                        <ShieldCheck className="w-4 h-4 text-slate-500 shrink-0" />
                        <span>
                          Verified CR Remover UPI QR · Receipt issued immediately
                        </span>
                      </div>
                    </form>
                  </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Fullscreen QR Lightbox Dialog */}
      {qrZoomOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Enlarged UPI Payment QR Code"
          className="fixed inset-0 z-50 bg-slate-950/75 flex items-center justify-center p-4"
          onClick={() => setQrZoomOpen(false)}
        >
          <div
            className="bg-[#1F2024] text-white rounded-2xl max-w-sm w-full p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-3">
              <div>
                <h4 className="text-base font-bold">CR Remover UPI QR</h4>
                <p className="text-xs text-slate-300 font-mono tabular-nums">
                  Payable Amount: {formatInr(displayAmount)}
                </p>
              </div>
              <button
                type="button"
                aria-label="Close zoomed QR code"
                onClick={() => setQrZoomOpen(false)}
                className="w-9 h-9 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <UpiQrCard payload={upiPayload} />
            <p className="mt-3 text-xs text-slate-300 text-center">
              Scan with PhonePe, Google Pay, Paytm, or BHIM UPI
            </p>
          </div>
        </div>
      )}
    </section>
  );
}
