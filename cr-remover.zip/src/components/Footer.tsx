export function Footer() {
  return (
    <footer className="bg-white border-t border-slate-200 py-10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div>
          <div className="text-base font-bold text-slate-950">CR Remover</div>
          <p className="text-sm text-slate-500 mt-1">
            Creator Rights &amp; Copyright Claim Clearance Desk · UPI QR Verified
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-6 text-sm text-slate-600">
          <a href="#services" className="hover:text-slate-950">
            Services
          </a>
          <a href="#checkout" className="hover:text-slate-950">
            UPI Checkout
          </a>
          <a href="#track" className="hover:text-slate-950">
            Track Case
          </a>
          <a href="#faq" className="hover:text-slate-950">
            FAQ
          </a>
        </div>
      </div>
    </footer>
  );
}
