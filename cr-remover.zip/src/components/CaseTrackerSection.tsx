import { FormEvent, useEffect, useState } from 'react';
import { CheckCircle2, Clock, FileCheck2, Search } from 'lucide-react';
import {
  CaseOrder,
  formatInr,
  getPaymentAppLabel,
  getStatusLabel,
} from '../utils/paymentLogic';

interface CaseTrackerSectionProps {
  orders: CaseOrder[];
  focusedCaseId: string | null;
}

function StatusIcon({ status }: { status: CaseOrder['status'] }) {
  if (status === 'claim_released') {
    return <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />;
  }
  if (status === 'dispute_filed') {
    return <FileCheck2 className="w-4 h-4 text-[#1E40AF] shrink-0" />;
  }
  return <Clock className="w-4 h-4 text-amber-700 shrink-0" />;
}

export function CaseTrackerSection({ orders, focusedCaseId }: CaseTrackerSectionProps) {
  const [query, setQuery] = useState(focusedCaseId ?? 'CR-2026-1042');
  const [searchedId, setSearchedId] = useState(focusedCaseId ?? 'CR-2026-1042');

  useEffect(() => {
    if (focusedCaseId) {
      setQuery(focusedCaseId);
      setSearchedId(focusedCaseId);
    }
  }, [focusedCaseId]);

  const normalizedSearch = searchedId.trim().toUpperCase();
  const matchedOrder = orders.find((o) => o.caseId.toUpperCase() === normalizedSearch);

  function handleSearch(e: FormEvent) {
    e.preventDefault();
    setSearchedId(query);
  }

  return (
    <section id="track" className="scroll-mt-16 py-16 sm:py-20 bg-white border-b border-slate-200/80">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          <div className="lg:col-span-5">
            <p className="text-sm font-medium text-slate-500 mb-2">Live Case Lookup</p>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
              Track your copyright case &amp; payment status
            </h2>
            <p className="mt-3 text-base text-slate-600 leading-relaxed mb-6">
              Enter your Case ID to view UPI verification status, UTR receipt, and dispute filing
              progress.
            </p>

            <form onSubmit={handleSearch} className="flex gap-2.5">
              <div className="flex-1">
                <label htmlFor="case-tracker-input" className="sr-only">
                  Case ID
                </label>
                <input
                  id="case-tracker-input"
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Enter Case ID (e.g. CR-2026-1042)"
                  className="w-full px-3.5 py-2.5 text-sm font-mono uppercase text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF] focus:ring-2 focus:ring-[#1E40AF]/15"
                />
              </div>
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-slate-950 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Search className="w-4 h-4" />
                <span>Track</span>
              </button>
            </form>

            <div className="mt-6">
              <p className="text-xs font-medium text-slate-500 mb-2.5">Recent &amp; Sample Cases</p>
              <div className="flex flex-wrap gap-2">
                {orders.slice(0, 5).map((item) => (
                  <button
                    key={item.caseId}
                    type="button"
                    onClick={() => {
                      setQuery(item.caseId);
                      setSearchedId(item.caseId);
                    }}
                    className={`px-3 py-1.5 text-xs font-mono tabular-nums rounded-md border transition-colors cursor-pointer ${
                      normalizedSearch === item.caseId.toUpperCase()
                        ? 'border-[#1E40AF] bg-[#1E40AF]/5 text-[#1E40AF] font-semibold'
                        : 'border-slate-200 bg-[#F8FAFC] text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    {item.caseId}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            {matchedOrder ? (
              <div
                data-testid="tracker-result"
                className="rounded-xl border border-slate-200 bg-[#F8FAFC] p-6 sm:p-7"
              >
                <div className="flex flex-wrap items-center justify-between gap-4 pb-4 mb-5 border-b border-slate-200">
                  <div>
                    <div className="text-xs font-medium text-slate-500">Case Reference</div>
                    <div className="text-xl font-bold text-slate-950 font-mono tabular-nums mt-0.5">
                      {matchedOrder.caseId}
                    </div>
                  </div>

                  <div className="inline-flex items-center gap-2 text-sm font-semibold text-slate-900">
                    <StatusIcon status={matchedOrder.status} />
                    <span>{getStatusLabel(matchedOrder.status)}</span>
                  </div>
                </div>

                <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                  <div>
                    <dt className="text-xs font-medium text-slate-500">Service Plan</dt>
                    <dd className="mt-1 font-semibold text-slate-900">
                      {matchedOrder.serviceTitle}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs font-medium text-slate-500">Fee Amount</dt>
                    <dd className="mt-1 font-bold text-slate-950 font-mono tabular-nums">
                      {formatInr(matchedOrder.amountInr)}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs font-medium text-slate-500">Creator &amp; Platform</dt>
                    <dd className="mt-1 text-slate-800">
                      {matchedOrder.creatorName} · {matchedOrder.platform}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs font-medium text-slate-500">
                      {matchedOrder.paymentMethod === 'razorpay'
                        ? 'Payment Gateway & Reference'
                        : 'Payment Channel & UTR'}
                    </dt>
                    <dd className="mt-1 font-mono tabular-nums text-slate-800">
                      {matchedOrder.paymentMethod === 'razorpay' && matchedOrder.razorpayPaymentId
                        ? `Razorpay Gateway · ${matchedOrder.razorpayPaymentId}`
                        : matchedOrder.utrNumber
                          ? `${getPaymentAppLabel(matchedOrder.paymentApp)} · ${matchedOrder.utrNumber}`
                          : 'Pending payment confirmation'}
                    </dd>
                  </div>
                  <div className="sm:col-span-2">
                    <dt className="text-xs font-medium text-slate-500">Video URL</dt>
                    <dd className="mt-1 text-slate-700 break-all">{matchedOrder.videoUrl}</dd>
                  </div>
                </dl>
              </div>
            ) : (
              <div
                data-testid="tracker-empty"
                className="rounded-xl border border-slate-200 bg-[#F8FAFC] p-8 text-center"
              >
                <p className="text-base font-semibold text-slate-900">
                  No case found for &ldquo;{searchedId.trim() || 'empty query'}&rdquo;
                </p>
                <p className="text-sm text-slate-600 mt-1.5">
                  Check your Case ID format (for example CR-2026-1042) or submit a new copyright
                  claim above.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
