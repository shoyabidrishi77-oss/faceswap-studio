import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

const FAQ_ITEMS = [
  {
    q: 'Do I need to share my YouTube or Instagram login password?',
    a: 'No. We never ask for your Google, YouTube Studio, or Instagram password. We only need the public video URL, claim details, and your contact information to prepare the formal dispute or retraction filing.',
  },
  {
    q: 'How do I pay using Google Pay, Paytm, or PhonePe?',
    a: 'Select your removal plan, generate your Case ID, and scan our verified UPI QR code using PhonePe, Google Pay, Paytm, or any BHIM UPI app. After paying the exact INR fee, enter the 12-digit UTR number to lock your receipt.',
  },
  {
    q: 'Where can I find my 12-digit UTR / UPI Reference Number?',
    a: 'In PhonePe, open History → tap the transaction → copy the 12-digit UTR. In Google Pay, open the payment → view UPI Transaction ID. In Paytm, open Balance & History → copy the 12-digit UPI Ref No.',
  },
  {
    q: 'How long does it take to release a Content ID claim or strike?',
    a: 'Most YouTube Content ID claims and Reels audio blocks are reviewed within 24–72 hours after payment verification. Formal DMCA copyright strike retractions typically take 2–5 business days depending on claimant response.',
  },
];

export function FaqSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="scroll-mt-16 py-16 sm:py-20 bg-[#F8FAFC]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-10">
          <p className="text-sm font-medium text-slate-500 mb-2">Common Questions</p>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
            Frequently asked questions
          </h2>
        </div>

        <div className="divide-y divide-slate-200 border-t border-b border-slate-200 bg-white rounded-xl px-6">
          {FAQ_ITEMS.map((item, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div key={item.q} className="py-5">
                <button
                  type="button"
                  aria-expanded={isOpen}
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  className="w-full flex items-center justify-between gap-4 text-left cursor-pointer"
                >
                  <span className="text-base font-semibold text-slate-950">{item.q}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-slate-500 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <p className="mt-3 text-sm sm:text-base text-slate-600 leading-relaxed pr-8">
                    {item.a}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
