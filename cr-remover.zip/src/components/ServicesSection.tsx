import { Check } from 'lucide-react';
import { SERVICE_PLANS, ServicePlan, formatInr } from '../utils/paymentLogic';

interface ServicesSectionProps {
  selectedServiceId: string;
  onSelectService: (plan: ServicePlan) => void;
}

export function ServicesSection({ selectedServiceId, onSelectService }: ServicesSectionProps) {
  return (
    <section id="services" className="scroll-mt-16 py-16 sm:py-20 bg-[#F8FAFC] border-b border-slate-200/80">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-10 sm:mb-12">
          <p className="text-sm font-medium text-slate-500 mb-2">
            Transparent Pricing · Fixed Fee per Case
          </p>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
            Select a copyright removal service
          </h2>
          <p className="mt-3 text-base text-slate-600 leading-relaxed">
            Every plan includes full dispute documentation, claimant correspondence tracking, and
            direct UPI checkout with zero hidden surcharges.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {SERVICE_PLANS.map((plan, index) => {
            const isSelected = plan.id === selectedServiceId;
            const isFullRow = SERVICE_PLANS.length % 2 === 1 && index === SERVICE_PLANS.length - 1;
            return (
              <div
                key={plan.id}
                className={`flex flex-col justify-between rounded-xl p-6 sm:p-7 bg-white transition-all duration-200 ${
                  isFullRow ? 'md:col-span-2' : ''
                } ${
                  isSelected
                    ? 'border-2 border-[#1E40AF] shadow-sm'
                    : 'border border-slate-200 hover:border-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-baseline justify-between gap-4 mb-3">
                    <span className="text-sm font-semibold text-slate-500 font-mono tabular-nums">
                      {plan.code}. {plan.scope}
                    </span>
                    <span className="text-sm text-slate-500 whitespace-nowrap">
                      {plan.turnaround}
                    </span>
                  </div>

                  <div className="flex items-baseline justify-between gap-4 mb-3">
                    <h3 className="text-xl font-bold tracking-tight text-slate-950">
                      {plan.title}
                    </h3>
                    <div className="text-2xl font-bold text-slate-950 font-mono tabular-nums shrink-0">
                      {formatInr(plan.priceInr)}
                    </div>
                  </div>

                  <p className="text-sm sm:text-base text-slate-600 leading-relaxed mb-6">
                    {plan.subtitle}
                  </p>

                  <ul
                    className={`mb-7 border-t border-slate-100 pt-5 ${
                      isFullRow
                        ? 'grid grid-cols-1 sm:grid-cols-3 gap-3'
                        : 'space-y-2.5'
                    }`}
                  >
                    {plan.deliverables.map((item) => (
                      <li key={item} className="flex items-start gap-2.5 text-sm text-slate-700">
                        <Check className="w-4 h-4 text-[#1E40AF] shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  type="button"
                  onClick={() => onSelectService(plan)}
                  className={`w-full py-3 px-4 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1E40AF] ${
                    isSelected
                      ? 'bg-[#1E40AF] text-white hover:bg-[#1E3A8A]'
                      : 'bg-slate-900 text-white hover:bg-slate-800'
                  }`}
                >
                  {isSelected ? `Selected · Pay ${formatInr(plan.priceInr)}` : `Select Plan · ${formatInr(plan.priceInr)}`}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
