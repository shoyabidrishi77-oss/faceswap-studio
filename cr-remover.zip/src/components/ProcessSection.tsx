export function ProcessSection() {
  const steps = [
    {
      num: '01',
      title: 'Submit Claim & Video URL',
      desc: 'Choose your removal package and share the claimed video link along with your contact details. No channel credentials required.',
    },
    {
      num: '02',
      title: 'Pay via QR or UPI App',
      desc: 'Scan our verified UPI QR code or pick Google Pay, PhonePe, or Paytm to pay the exact fixed fee.',
    },
    {
      num: '03',
      title: 'Verify 12-Digit UTR Number',
      desc: 'Enter your 12-digit UPI transaction reference ID to lock your Case ID and generate your payment receipt.',
    },
    {
      num: '04',
      title: 'Dispute Filed & Claim Cleared',
      desc: 'Our rights desk files the formal dispute or retraction request and updates your Case Tracker until release.',
    },
  ];

  return (
    <section id="process" className="scroll-mt-16 py-16 sm:py-20 bg-white border-b border-slate-200/80">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-10 sm:mb-12">
          <p className="text-sm font-medium text-slate-500 mb-2">Workflow · 4 Clear Steps</p>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
            How claim removal &amp; UPI verification work
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step) => (
            <div key={step.num} className="pt-5 border-t border-slate-200">
              <div className="text-sm font-bold text-[#1E40AF] font-mono tabular-nums mb-2">
                {step.num}
              </div>
              <h3 className="text-base font-bold text-slate-950 mb-2">{step.title}</h3>
              <p className="text-sm text-slate-600 leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
