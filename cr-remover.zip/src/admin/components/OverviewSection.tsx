import { ArrowRight } from 'lucide-react';
import {
  AdminOrder,
  AdminPaymentRecord,
  AuditLogDoc,
  DashboardSummaryStats,
  ORDER_STATUS_LABELS,
  PAYMENT_STATUS_LABELS,
  UPI_APP_LABELS,
  formatInr,
  formatIsoDate,
} from '../utils/adminLogic';
import type { AdminSectionId } from './AdminShell';

interface OverviewSectionProps {
  loading: boolean;
  stats: DashboardSummaryStats;
  orders: AdminOrder[];
  payments: AdminPaymentRecord[];
  auditLogs: AuditLogDoc[];
  onNavigate: (section: AdminSectionId) => void;
}

export function OverviewSection({
  loading,
  stats,
  orders,
  payments,
  auditLogs,
  onNavigate,
}: OverviewSectionProps) {
  const recentOrders = orders.slice(0, 6);
  const pendingPayments = payments.filter((p) => p.verificationStatus === 'pending').slice(0, 6);
  const recentLogs = auditLogs.slice(0, 6);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-950">
          Operations Overview
        </h1>
        <p className="mt-1 text-sm text-slate-600">
          Live counts and verified financial totals read directly from Cloud Firestore.
        </p>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Total Claim Orders</div>
          <div className="mt-2 text-2xl font-bold text-slate-950 font-mono tabular-nums">
            {loading ? '—' : stats.totalOrders}
          </div>
          <div className="mt-1.5 text-xs text-slate-500 font-mono tabular-nums">
            {stats.pendingOrders} pending · {stats.releasedOrders} released
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Verified Revenue</div>
          <div className="mt-2 text-2xl font-bold text-slate-950 font-mono tabular-nums">
            {loading ? '—' : formatInr(stats.verifiedRevenueInr)}
          </div>
          <div className="mt-1.5 text-xs text-slate-500 font-mono tabular-nums">
            {stats.verifiedPayments} verified payment{stats.verifiedPayments === 1 ? '' : 's'}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Pending Payment Reviews</div>
          <div className="mt-2 text-2xl font-bold text-slate-950 font-mono tabular-nums">
            {loading ? '—' : stats.pendingPayments}
          </div>
          <div className="mt-1.5 text-xs text-slate-500 font-mono tabular-nums">
            {stats.totalPayments} total payment records
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Registered Users &amp; Admins</div>
          <div className="mt-2 text-2xl font-bold text-slate-950 font-mono tabular-nums">
            {loading ? '—' : stats.registeredUsers}
          </div>
          <div className="mt-1.5 text-xs text-slate-500 font-mono tabular-nums">
            {stats.activeAdmins} active admin{stats.activeAdmins === 1 ? '' : 's'}
          </div>
        </div>
      </div>

      {/* Main Queues */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
            <h2 className="text-base font-bold text-slate-950">Recent Orders</h2>
            <button
              type="button"
              onClick={() => onNavigate('orders')}
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#1E40AF] hover:underline cursor-pointer whitespace-nowrap"
            >
              <span>Manage All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {recentOrders.length === 0 ? (
            <div className="p-8 text-center">
              <p className="text-sm font-medium text-slate-900">No orders recorded yet</p>
              <p className="mt-1 text-xs text-slate-500">
                Real copyright claim orders submitted through your portal will appear here.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentOrders.map((order) => (
                <div
                  key={order.caseId}
                  className="px-5 py-3.5 flex items-center justify-between gap-4 hover:bg-slate-50"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-slate-950 font-mono tabular-nums truncate">
                      {order.caseId} · {order.creatorName}
                    </div>
                    <div className="text-xs text-slate-500 truncate mt-0.5">
                      {order.serviceTitle} · {order.platform}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-sm font-bold text-slate-950 font-mono tabular-nums">
                      {formatInr(order.amountInr)}
                    </div>
                    <div className="text-xs text-slate-600 mt-0.5">
                      {ORDER_STATUS_LABELS[order.status] ?? order.status}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Payment Verification Queue */}
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
            <h2 className="text-base font-bold text-slate-950">Payment Verification Queue</h2>
            <button
              type="button"
              onClick={() => onNavigate('payments')}
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#1E40AF] hover:underline cursor-pointer whitespace-nowrap"
            >
              <span>Review Payments</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {pendingPayments.length === 0 ? (
            <div className="p-8 text-center">
              <p className="text-sm font-medium text-slate-900">No pending UPI payments</p>
              <p className="mt-1 text-xs text-slate-500">
                Real UPI UTR submissions awaiting administrator verification will appear here.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {pendingPayments.map((payment) => (
                <div
                  key={payment.paymentId}
                  className="px-5 py-3.5 flex items-center justify-between gap-4 hover:bg-slate-50"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-slate-950 font-mono tabular-nums truncate">
                      UTR {payment.utrNumber} · {UPI_APP_LABELS[payment.paymentApp]}
                    </div>
                    <div className="text-xs text-slate-500 truncate mt-0.5">
                      Case {payment.caseId} · {payment.payerName}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-sm font-bold text-slate-950 font-mono tabular-nums">
                      {formatInr(payment.amountInr)}
                    </div>
                    <div className="text-xs text-amber-700 mt-0.5">
                      {PAYMENT_STATUS_LABELS[payment.verificationStatus]}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Audit Activity */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <h2 className="text-base font-bold text-slate-950">Recent Administrative Audit Logs</h2>
          <button
            type="button"
            onClick={() => onNavigate('settings')}
            className="inline-flex items-center gap-1 text-xs font-semibold text-[#1E40AF] hover:underline cursor-pointer whitespace-nowrap"
          >
            <span>Full Audit Trail</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {recentLogs.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-sm font-medium text-slate-900">No administrative changes logged yet</p>
            <p className="mt-1 text-xs text-slate-500">
              Every order, payment, user, content, or settings change records an immutable audit log entry.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {recentLogs.map((log) => (
              <div
                key={log.logId}
                className="px-5 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-sm"
              >
                <div className="min-w-0">
                  <span className="font-semibold text-slate-950">{log.summary}</span>
                  <span className="text-slate-400 mx-2">·</span>
                  <span className="text-xs text-slate-500">{log.actorEmail}</span>
                </div>
                <div className="text-xs text-slate-500 font-mono tabular-nums shrink-0">
                  {formatIsoDate(log.createdAt)}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
