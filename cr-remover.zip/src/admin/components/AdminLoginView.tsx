import { FormEvent, useState } from 'react';
import {
  AlertCircle,
  ExternalLink,
  Eye,
  EyeOff,
  Lock,
  LogOut,
  MailCheck,
  ShieldCheck,
} from 'lucide-react';

interface AdminLoginViewProps {
  loading: boolean;
  signingIn: boolean;
  error: string | null;
  unauthorizedEmail: string | null;
  needsEmailVerification: boolean;
  verificationSent: boolean;
  onEmailPasswordSignIn: (email: string, password: string) => Promise<void>;
  onGoogleSignIn: () => Promise<void>;
  onSendVerificationEmail: () => Promise<void>;
  onSignOut: () => Promise<void>;
}

export function AdminLoginView({
  loading,
  signingIn,
  error,
  unauthorizedEmail,
  needsEmailVerification,
  verificationSent,
  onEmailPasswordSignIn,
  onGoogleSignIn,
  onSendVerificationEmail,
  onSignOut,
}: AdminLoginViewProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [formValidationError, setFormValidationError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const cleanEmail = email.trim();
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(cleanEmail)) {
      setFormValidationError('Enter a valid administrator email address.');
      return;
    }
    if (password.length < 6) {
      setFormValidationError('Enter your password (at least 6 characters).');
      return;
    }
    setFormValidationError(null);
    await onEmailPasswordSignIn(cleanEmail, password);
  }

  const displayedError = formValidationError ?? error;

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col justify-between px-4 py-8 sm:px-6 lg:px-8">
      <header className="max-w-5xl w-full mx-auto flex items-center justify-between gap-4">
        <a
          href="/admin"
          className="text-lg font-bold tracking-tight text-slate-950 whitespace-nowrap shrink-0"
        >
          CR Remover Admin
        </a>
        <a
          href="/"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-600 hover:text-slate-950 whitespace-nowrap shrink-0"
        >
          <span>Main Website</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </header>

      <main className="max-w-md w-full mx-auto my-10">
        <div className="bg-white border border-slate-200 rounded-xl p-7 sm:p-8">
          <div className="w-11 h-11 rounded-lg bg-[#0F172A] text-white flex items-center justify-center mb-5">
            <ShieldCheck className="w-5 h-5" />
          </div>

          <p className="text-xs font-medium text-slate-500 mb-1.5">
            Restricted Operations Portal
          </p>
          <h1 className="text-2xl font-bold tracking-tight text-slate-950">
            Administrator Sign In
          </h1>
          <p className="mt-2 text-sm text-slate-600 leading-relaxed">
            Sign in with your authorized administrator credentials. Access is verified server-side
            via Firebase Authentication and Firestore Security Rules.
          </p>

          {displayedError && (
            <div
              role="alert"
              className="mt-5 p-3.5 rounded-lg bg-red-50 border border-red-200 flex items-start gap-2.5 text-sm text-red-800"
            >
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-700" />
              <span>{displayedError}</span>
            </div>
          )}

          {unauthorizedEmail ? (
            <div className="mt-6 space-y-4">
              <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 text-sm text-slate-700">
                Signed in as{' '}
                <span className="font-semibold text-slate-950">{unauthorizedEmail}</span>.{' '}
                {needsEmailVerification
                  ? 'Please verify your email address before accessing administrator operations.'
                  : 'This account does not hold administrator privileges in Firebase RBAC.'}
              </div>

              {needsEmailVerification && (
                <button
                  type="button"
                  disabled={verificationSent}
                  onClick={onSendVerificationEmail}
                  className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] disabled:opacity-60 rounded-lg inline-flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
                >
                  <MailCheck className="w-4 h-4" />
                  <span>
                    {verificationSent ? 'Verification Email Sent' : 'Send Verification Email'}
                  </span>
                </button>
              )}

              <button
                type="button"
                onClick={onSignOut}
                className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-slate-950 hover:bg-slate-800 rounded-lg inline-flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out &amp; Switch Account</span>
              </button>
            </div>
          ) : (
            <div className="mt-6 space-y-5">
              <form onSubmit={handleSubmit} noValidate className="space-y-4">
                <div>
                  <label
                    htmlFor="admin-email-input"
                    className="block text-sm font-medium text-slate-800 mb-1.5"
                  >
                    Admin Email
                  </label>
                  <input
                    id="admin-email-input"
                    type="email"
                    autoComplete="email"
                    required
                    disabled={loading || signingIn}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="admin@domain.com"
                    className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg placeholder:text-slate-400 focus:outline-none focus:border-[#1E40AF] focus:ring-2 focus:ring-[#1E40AF]/15 disabled:bg-slate-50"
                  />
                </div>

                <div>
                  <label
                    htmlFor="admin-password-input"
                    className="block text-sm font-medium text-slate-800 mb-1.5"
                  >
                    Password
                  </label>
                  <div className="relative">
                    <input
                      id="admin-password-input"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                      required
                      disabled={loading || signingIn}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      className="w-full pl-3.5 pr-10 py-2.5 text-sm text-slate-900 bg-white border border-slate-300 rounded-lg placeholder:text-slate-400 focus:outline-none focus:border-[#1E40AF] focus:ring-2 focus:ring-[#1E40AF]/15 disabled:bg-slate-50"
                    />
                    <button
                      type="button"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                      onClick={() => setShowPassword((prev) => !prev)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-500 hover:text-slate-800 cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading || signingIn}
                  className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] disabled:opacity-60 rounded-lg transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1E40AF] whitespace-nowrap"
                >
                  {loading
                    ? 'Checking session...'
                    : signingIn
                      ? 'Authenticating...'
                      : 'Sign In to Dashboard'}
                </button>
              </form>

              <div className="relative flex items-center py-1">
                <div className="flex-grow border-t border-slate-200" />
                <span className="shrink-0 mx-3 text-xs text-slate-400">or</span>
                <div className="flex-grow border-t border-slate-200" />
              </div>

              <button
                type="button"
                disabled={loading || signingIn}
                onClick={onGoogleSignIn}
                className="w-full py-2.5 px-4 text-sm font-semibold text-slate-800 bg-white border border-slate-300 hover:bg-slate-50 disabled:opacity-60 rounded-lg inline-flex items-center justify-center gap-2.5 transition-colors cursor-pointer whitespace-nowrap"
              >
                <svg aria-hidden="true" className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="currentColor"
                    d="M21.35 11.1h-9.17v2.73h6.51c-.33 3.81-3.5 5.44-6.5 5.44C8.36 19.27 5 16.25 5 12c0-4.1 3.2-7.27 7.2-7.27c3.09 0 4.9 1.97 4.9 1.97L19 4.72S16.56 2 12.1 2C6.42 2 2.03 6.8 2.03 12c0 5.05 4.13 10 10.22 10c5.35 0 9.25-3.67 9.25-9.09c0-1.15-.15-1.81-.15-1.81Z"
                  />
                </svg>
                <span>Continue with Google</span>
              </button>

              <div className="pt-4 border-t border-slate-100 flex items-start gap-2.5 text-xs text-slate-500">
                <Lock className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <span>
                  Zero client-side secrets or hardcoded passwords. Every admin request carries a
                  verified Firebase ID token checked server-side and by Firestore Security Rules.
                </span>
              </div>
            </div>
          )}
        </div>
      </main>

      <footer className="max-w-5xl w-full mx-auto text-xs text-slate-500 flex flex-wrap items-center justify-between gap-4">
        <span>CR Remover Operations Console</span>
        <span>Firebase Auth &amp; Firestore Protected</span>
      </footer>
    </div>
  );
}
