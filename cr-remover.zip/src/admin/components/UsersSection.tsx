import { useState } from 'react';
import { Search } from 'lucide-react';
import {
  AdminRoleRecord,
  AdminUserRecord,
  filterUsers,
  formatIsoDate,
} from '../utils/adminLogic';

interface UsersSectionProps {
  currentAdminUid: string;
  users: AdminUserRecord[];
  admins: AdminRoleRecord[];
  onUpdateUser: (
    uid: string,
    updates: { role: AdminUserRecord['role']; status: AdminUserRecord['status'] }
  ) => Promise<void>;
}

export function UsersSection({
  currentAdminUid,
  users,
  admins,
  onUpdateUser,
}: UsersSectionProps) {
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<AdminUserRecord['role'] | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<AdminUserRecord['status'] | 'all'>('all');
  const [busyUid, setBusyUid] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const filtered = filterUsers(users, search, roleFilter, statusFilter);

  async function handleRoleOrStatusChange(
    user: AdminUserRecord,
    nextRole: AdminUserRecord['role'],
    nextStatus: AdminUserRecord['status']
  ) {
    setBusyUid(user.uid);
    setError(null);
    try {
      await onUpdateUser(user.uid, { role: nextRole, status: nextStatus });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update user.');
    } finally {
      setBusyUid(null);
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-950">User Management</h1>
        <p className="mt-1 text-sm text-slate-600">
          Manage real registered accounts, creator permissions, and authorized administrator RBAC.
        </p>
      </div>

      {error && (
        <p role="alert" className="text-sm font-medium text-red-700">
          {error}
        </p>
      )}

      {/* Authorized Administrators Directory */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <h2 className="text-base font-bold text-slate-950">Authorized Administrators</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Accounts verified in Firestore RBAC (`/admins`) and server authorization.
          </p>
        </div>

        {admins.length === 0 ? (
          <div className="p-6 text-sm text-slate-500">
            No administrator records synced yet. Your verified session automatically registers access.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-4">Administrator</th>
                  <th className="py-3 px-4">UID</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">State</th>
                  <th className="py-3 px-4">Updated</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {admins.map((admin) => (
                  <tr key={admin.uid}>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-950">{admin.displayName}</div>
                      <div className="text-xs text-slate-500">{admin.email}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-xs text-slate-600">{admin.uid}</td>
                    <td className="py-3 px-4 text-xs font-semibold text-slate-800 capitalize">
                      {admin.role.replace('_', ' ')}
                    </td>
                    <td className="py-3 px-4 text-xs font-semibold">
                      <span className={admin.active ? 'text-emerald-700' : 'text-red-700'}>
                        {admin.active ? 'Active' : 'Disabled'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-500 font-mono tabular-nums whitespace-nowrap">
                      {formatIsoDate(admin.updatedAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Registered Creator & Staff Accounts */}
      <section className="space-y-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-6 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              aria-label="Search registered users"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by display name, channel, UID, or email..."
              className="w-full pl-9 pr-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
            />
          </div>
          <div className="md:col-span-3">
            <select
              aria-label="Filter users by role"
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value as AdminUserRecord['role'] | 'all')}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:border-[#1E40AF]"
            >
              <option value="all">All Roles</option>
              <option value="creator">Creator</option>
              <option value="moderator">Moderator</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <div className="md:col-span-3">
            <select
              aria-label="Filter users by account status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as AdminUserRecord['status'] | 'all')}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:border-[#1E40AF]"
            >
              <option value="all">All Account States</option>
              <option value="active">Active</option>
              <option value="suspended">Suspended</option>
            </select>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          {filtered.length === 0 ? (
            <div className="p-10 text-center">
              <p className="text-sm font-semibold text-slate-900">
                {users.length === 0 ? 'No registered creator accounts yet' : 'No matching users'}
              </p>
              <p className="mt-1 text-xs text-slate-500">
                Real user accounts created via Firebase Authentication and saved to Firestore will
                appear here. No fake accounts are generated.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4">User / Channel</th>
                    <th className="py-3 px-4">UID</th>
                    <th className="py-3 px-4 text-right">Cases</th>
                    <th className="py-3 px-4">Role</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filtered.map((user) => {
                    const isSelf = user.uid === currentAdminUid;
                    return (
                      <tr key={user.uid} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-950">{user.displayName}</div>
                          <div className="text-xs text-slate-500">
                            {user.channelName || 'No channel'} {user.email ? `· ${user.email}` : ''}
                          </div>
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-slate-600">{user.uid}</td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-900">
                          {user.totalCases}
                        </td>
                        <td className="py-3 px-4">
                          <select
                            aria-label={`Change role for ${user.displayName}`}
                            disabled={busyUid === user.uid || isSelf}
                            value={user.role}
                            onChange={(e) =>
                              handleRoleOrStatusChange(
                                user,
                                e.target.value as AdminUserRecord['role'],
                                user.status
                              )
                            }
                            className="px-2.5 py-1 text-xs border border-slate-300 rounded-md bg-white disabled:bg-slate-50"
                          >
                            <option value="creator">Creator</option>
                            <option value="moderator">Moderator</option>
                            <option value="admin">Admin</option>
                          </select>
                        </td>
                        <td className="py-3 px-4 text-xs font-semibold">
                          <span
                            className={user.status === 'active' ? 'text-emerald-700' : 'text-red-700'}
                          >
                            {user.status === 'active' ? 'Active' : 'Suspended'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <button
                            type="button"
                            disabled={busyUid === user.uid || isSelf}
                            onClick={() =>
                              handleRoleOrStatusChange(
                                user,
                                user.role,
                                user.status === 'active' ? 'suspended' : 'active'
                              )
                            }
                            className="px-3 py-1 text-xs font-semibold text-slate-700 border border-slate-300 hover:bg-slate-50 disabled:opacity-40 rounded-md cursor-pointer whitespace-nowrap"
                          >
                            {user.status === 'active' ? 'Suspend' : 'Activate'}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
