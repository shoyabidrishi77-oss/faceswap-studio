import {
  AdminOrder,
  AdminPaymentRecord,
  AnalyticsDailyDoc,
  computePaymentChannelBreakdown,
  computePlatformBreakdown,
  formatInr,
} from '../utils/adminLogic';

interface AnalyticsSectionProps {
  orders: AdminOrder[];
  payments: AdminPaymentRecord[];
  analyticsDaily: AnalyticsDailyDoc[];
}

export function AnalyticsSection({
  orders,
  payments,
  analyticsDaily,
}: AnalyticsSectionProps) {
  const platformStats = computePlatformBreakdown(orders);
  const channelStats = computePaymentChannelBreakdown(payments);

  const maxPlatformCount = Math.max(1, ...platformStats.map((item) => item.count));
  const maxChannelCount = Math.max(1, ...channelStats.map((item) => item.count));

  const sortedDaily = [...analyticsDaily].sort((a, b) => b.dateKey.localeCompare(a.dateKey));
  const totalViews = sortedDaily.reduce((acc, row) => acc + (row.pageViews || 0), 0);
  const totalCheckouts = sortedDaily.reduce((acc, row) => acc + (row.checkoutStarts || 0), 0);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-950">Website Analytics</h1>
        <p className="mt-1 text-sm text-slate-600">
          Real platform demand, UPI payment channel distribution, and daily funnel counts stored in
          Firestore.
        </p>
      </div>

      {/* Funnel Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Tracked Page Views</div>
          <div className="mt-2 text-2xl font-bold text-slate-950 font-mono tabular-nums">
            {totalViews.toLocaleString('en-IN')}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Checkout Initiations</div>
          <div className="mt-2 text-2xl font-bold text-slate-950 font-mono tabular-nums">
            {totalCheckouts.toLocaleString('en-IN')}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Recorded Orders</div>
          <div className="mt-2 text-2xl font-bold text-slate-950 font-mono tabular-nums">
            {orders.length.toLocaleString('en-IN')}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Verified Payments</div>
          <div className="mt-2 text-2xl font-bold text-slate-950 font-mono tabular-nums">
            {payments.filter((p) => p.verificationStatus === 'verified').length.toLocaleString('en-IN')}
          </div>
        </div>
      </div>

      {/* Platform & Payment Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          <div>
            <h2 className="text-base font-bold text-slate-950">Orders by Platform</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Distribution across YouTube, Shorts, Instagram Reels, and Facebook Video.
            </p>
          </div>
          <div className="space-y-4">
            {platformStats.map((row) => {
              const widthPct = orders.length === 0 ? 0 : Math.round((row.count / maxPlatformCount) * 100);
              return (
                <div key={row.platform} className="space-y-1.5">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium text-slate-800">{row.platform}</span>
                    <span className="font-mono tabular-nums text-xs text-slate-600">
                      {row.count} orders · {formatInr(row.revenueInr)}
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full bg-[#1E40AF] transition-all duration-200"
                      style={{ width: `${widthPct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          <div>
            <h2 className="text-base font-bold text-slate-950">UPI Payment Channels</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Verified INR volume grouped by PhonePe, Google Pay, Paytm, and BHIM UPI.
            </p>
          </div>
          <div className="space-y-4">
            {channelStats.map((row) => {
              const widthPct =
                payments.length === 0 ? 0 : Math.round((row.count / maxChannelCount) * 100);
              return (
                <div key={row.channel} className="space-y-1.5">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium text-slate-800">{row.label}</span>
                    <span className="font-mono tabular-nums text-xs text-slate-600">
                      {row.count} txns · {formatInr(row.verifiedAmountInr)} verified
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full bg-slate-900 transition-all duration-200"
                      style={{ width: `${widthPct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>

      {/* Daily Snapshots Table */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <h2 className="text-base font-bold text-slate-950">Daily Traffic &amp; Conversion Log</h2>
        </div>

        {sortedDaily.length === 0 ? (
          <div className="p-10 text-center">
            <p className="text-sm font-semibold text-slate-900">No daily analytics snapshots recorded yet</p>
            <p className="mt-1 text-xs text-slate-500">
              Live page views and order conversion telemetry written to `/analyticsDaily` will display
              here chronologically.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4 text-right">Page Views</th>
                  <th className="py-3 px-4 text-right">Checkouts</th>
                  <th className="py-3 px-4 text-right">Orders</th>
                  <th className="py-3 px-4 text-right">Verified Txns</th>
                  <th className="py-3 px-4 text-right">Revenue</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm font-mono tabular-nums">
                {sortedDaily.map((row) => (
                  <tr key={row.dateKey} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-semibold text-slate-950">{row.dateKey}</td>
                    <td className="py-3 px-4 text-right text-slate-700">{row.pageViews}</td>
                    <td className="py-3 px-4 text-right text-slate-700">{row.checkoutStarts}</td>
                    <td className="py-3 px-4 text-right text-slate-700">{row.ordersCreated}</td>
                    <td className="py-3 px-4 text-right text-slate-700">{row.paymentsVerified}</td>
                    <td className="py-3 px-4 text-right font-semibold text-slate-950">
                      {formatInr(row.revenueInr)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
