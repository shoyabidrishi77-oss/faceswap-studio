import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  onAuthStateChanged,
  sendEmailVerification,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import { collection, onSnapshot } from 'firebase/firestore';
import { adminFetch } from './api';
import { AdminLoginView } from './components/AdminLoginView';
import { AdminShell, type AdminSectionId } from './components/AdminShell';
import { AnalyticsSection } from './components/AnalyticsSection';
import { ContentSection } from './components/ContentSection';
import { OrdersSection } from './components/OrdersSection';
import { OverviewSection } from './components/OverviewSection';
import { PaymentsSection } from './components/PaymentsSection';
import { SettingsSection } from './components/SettingsSection';
import { UsersSection } from './components/UsersSection';
import {
  OperationType,
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  testFirestoreConnection,
} from './firebase';
import {
  AdminOrder,
  AdminPaymentRecord,
  AdminRoleRecord,
  AdminUserRecord,
  AnalyticsDailyDoc,
  AuditLogDoc,
  FaqItemDoc,
  OrderStatus,
  PaymentVerificationStatus,
  ServicePlanDoc,
  SiteContentDoc,
  SiteSettingsDoc,
  computeDashboardStats,
} from './utils/adminLogic';

interface AdminSessionResponse {
  authorized: boolean;
  uid: string;
  email: string;
  displayName: string;
  role: string;
}

interface AdminOverviewResponse {
  orders: AdminOrder[];
  payments: AdminPaymentRecord[];
  users: AdminUserRecord[];
  admins: AdminRoleRecord[];
  analytics: AnalyticsDailyDoc[];
  auditLogs: AuditLogDoc[];
  siteContent: SiteContentDoc[];
  servicePlans: ServicePlanDoc[];
  faqs: FaqItemDoc[];
  settings: SiteSettingsDoc[];
}

function normalizeSnapshotData<T>(raw: Record<string, unknown>, id: string): T {
  const out: Record<string, unknown> = { _id: id };
  for (const [k, v] of Object.entries(raw)) {
    if (
      v &&
      typeof v === 'object' &&
      'toDate' in v &&
      typeof (v as { toDate: unknown }).toDate === 'function'
    ) {
      out[k] = (v as { toDate: () => Date }).toDate().toISOString();
    } else {
      out[k] = v;
    }
  }
  return out as T;
}

function getSectionFromPathname(pathname: string): AdminSectionId {
  const clean = pathname.replace(/\/+$/, '');
  if (clean.endsWith('/orders')) return 'orders';
  if (clean.endsWith('/payments')) return 'payments';
  if (clean.endsWith('/users')) return 'users';
  if (clean.endsWith('/analytics')) return 'analytics';
  if (clean.endsWith('/content')) return 'content';
  if (clean.endsWith('/settings')) return 'settings';
  return 'overview';
}

function getPathForSection(section: AdminSectionId): string {
  return section === 'overview' ? '/admin/dashboard' : `/admin/${section}`;
}

function mapFirebaseAuthError(err: unknown): string {
  if (err && typeof err === 'object' && 'code' in err) {
    const code = String((err as { code?: string }).code ?? '');
    if (code === 'auth/operation-not-allowed') {
      return 'Email/Password sign-in is not yet enabled in Firebase Authentication. Enable Email/Password under Firebase Console → Authentication → Sign-in method, or use Continue with Google.';
    }
    if (
      code === 'auth/invalid-credential' ||
      code === 'auth/wrong-password' ||
      code === 'auth/user-not-found'
    ) {
      return 'Invalid email or password. Please verify your Firebase administrator credentials.';
    }
    if (code === 'auth/too-many-requests') {
      return 'Too many sign-in attempts. Please wait a moment and try again.';
    }
    if (code === 'auth/popup-closed-by-user') {
      return 'Sign-in popup was closed before completion.';
    }
  }
  return err instanceof Error ? err.message : 'Authentication failed.';
}

export default function AdminApp() {
  const [authLoading, setAuthLoading] = useState(true);
  const [signingIn, setSigningIn] = useState(false);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [session, setSession] = useState<AdminSessionResponse | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [unauthorizedEmail, setUnauthorizedEmail] = useState<string | null>(null);
  const [verificationSent, setVerificationSent] = useState(false);

  const [activeSection, setActiveSection] = useState<AdminSectionId>(() =>
    getSectionFromPathname(window.location.pathname)
  );

  const [dataLoading, setDataLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [overview, setOverview] = useState<AdminOverviewResponse>({
    orders: [],
    payments: [],
    users: [],
    admins: [],
    analytics: [],
    auditLogs: [],
    siteContent: [],
    servicePlans: [],
    faqs: [],
    settings: [],
  });

  useEffect(() => {
    const onPopState = () => {
      setActiveSection(getSectionFromPathname(window.location.pathname));
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const loadOverview = useCallback(async (isRefresh = false) => {
    if (isRefresh) {
      setRefreshing(true);
    } else {
      setDataLoading(true);
    }
    try {
      const data = await adminFetch<AdminOverviewResponse>('/api/admin/overview');
      setOverview(data);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Failed to load admin data.');
    } finally {
      setDataLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    testFirestoreConnection().catch(() => {});

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      setAuthError(null);
      setUnauthorizedEmail(null);
      setVerificationSent(false);

      if (!user) {
        setSession(null);
        setAuthLoading(false);
        if (window.location.pathname.replace(/\/+$/, '') !== '/admin') {
          window.history.replaceState({}, '', '/admin');
        }
        return;
      }

      if (!user.emailVerified) {
        setSession(null);
        setUnauthorizedEmail(user.email ?? user.uid);
        setAuthError(
          'Your Firebase email address is not verified yet. Verify your email, then sign in again.'
        );
        setAuthLoading(false);
        return;
      }

      try {
        const verifiedSession = await adminFetch<AdminSessionResponse>('/api/admin/session');
        setSession(verifiedSession);
        setAuthLoading(false);
        const currentClean = window.location.pathname.replace(/\/+$/, '');
        if (currentClean === '/admin') {
          window.history.replaceState({}, '', '/admin/dashboard');
          setActiveSection('overview');
        }
        await loadOverview(false);
      } catch (err) {
        const msg =
          err instanceof Error
            ? err.message
            : 'Administrator authorization verification failed.';
        setSession(null);
        setUnauthorizedEmail(user.email ?? user.uid);
        setAuthError(msg);
        setAuthLoading(false);
      }
    });

    return () => unsubscribe();
  }, [loadOverview]);

  useEffect(() => {
    if (!session?.authorized) return;

    const subscriptions: Array<{ key: keyof AdminOverviewResponse; path: string }> = [
      { key: 'orders', path: 'orders' },
      { key: 'payments', path: 'payments' },
      { key: 'users', path: 'users' },
      { key: 'admins', path: 'admins' },
      { key: 'analytics', path: 'analyticsDaily' },
      { key: 'auditLogs', path: 'auditLogs' },
      { key: 'siteContent', path: 'siteContent' },
      { key: 'servicePlans', path: 'servicePlans' },
      { key: 'faqs', path: 'faqs' },
      { key: 'settings', path: 'settings' },
    ];

    const unsubs = subscriptions.map(({ key, path }) =>
      onSnapshot(
        collection(db, path),
        (snapshot) => {
          const docs = snapshot.docs.map((docSnap) =>
            normalizeSnapshotData(docSnap.data(), docSnap.id)
          );
          setOverview((prev) => ({ ...prev, [key]: docs }));
        },
        (error) => {
          handleFirestoreError(error, OperationType.LIST, path);
        }
      )
    );

    return () => {
      for (const unsub of unsubs) {
        unsub();
      }
    };
  }, [session?.authorized]);

  function handleNavigate(section: AdminSectionId) {
    setActiveSection(section);
    const targetPath = getPathForSection(section);
    if (window.location.pathname !== targetPath) {
      window.history.pushState({}, '', targetPath);
    }
  }

  async function handleEmailPasswordSignIn(email: string, password: string) {
    setSigningIn(true);
    setAuthError(null);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err) {
      setAuthError(mapFirebaseAuthError(err));
    } finally {
      setSigningIn(false);
    }
  }

  async function handleGoogleSignIn() {
    setSigningIn(true);
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      setAuthError(mapFirebaseAuthError(err));
    } finally {
      setSigningIn(false);
    }
  }

  async function handleSendVerificationEmail() {
    if (!auth.currentUser) return;
    try {
      await sendEmailVerification(auth.currentUser);
      setVerificationSent(true);
    } catch (err) {
      setAuthError(mapFirebaseAuthError(err));
    }
  }

  async function handleSignOut() {
    await signOut(auth);
    setSession(null);
    setUnauthorizedEmail(null);
    setAuthError(null);
    setVerificationSent(false);
    if (window.location.pathname !== '/admin') {
      window.history.replaceState({}, '', '/admin');
    }
  }

  const stats = useMemo(
    () =>
      computeDashboardStats({
        orders: overview.orders,
        payments: overview.payments,
        users: overview.users,
        admins: overview.admins,
      }),
    [overview]
  );

  if (!firebaseUser || !session?.authorized) {
    return (
      <AdminLoginView
        loading={authLoading}
        signingIn={signingIn}
        error={authError}
        unauthorizedEmail={unauthorizedEmail}
        needsEmailVerification={Boolean(firebaseUser && !firebaseUser.emailVerified)}
        verificationSent={verificationSent}
        onEmailPasswordSignIn={handleEmailPasswordSignIn}
        onGoogleSignIn={handleGoogleSignIn}
        onSendVerificationEmail={handleSendVerificationEmail}
        onSignOut={handleSignOut}
      />
    );
  }

  return (
    <AdminShell
      activeSection={activeSection}
      onNavigate={handleNavigate}
      adminEmail={session.email}
      adminRole={session.role}
      refreshing={refreshing}
      onRefresh={() => loadOverview(true)}
      onSignOut={handleSignOut}
    >
      {authError && (
        <div
          role="alert"
          className="mb-6 p-3.5 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800"
        >
          {authError}
        </div>
      )}

      {activeSection === 'overview' && (
        <OverviewSection
          loading={dataLoading}
          stats={stats}
          orders={overview.orders}
          payments={overview.payments}
          auditLogs={overview.auditLogs}
          onNavigate={handleNavigate}
        />
      )}

      {activeSection === 'orders' && (
        <OrdersSection
          orders={overview.orders}
          onUpdateOrder={async (caseId, updates: { status: OrderStatus; adminNotes: string }) => {
            await adminFetch(`/api/admin/orders/${encodeURIComponent(caseId)}`, {
              method: 'PATCH',
              body: JSON.stringify(updates),
            });
            await loadOverview(true);
          }}
        />
      )}

      {activeSection === 'payments' && (
        <PaymentsSection
          payments={overview.payments}
          onVerifyPayment={async (
            paymentId,
            verificationStatus: PaymentVerificationStatus,
            notes
          ) => {
            await adminFetch(`/api/admin/payments/${encodeURIComponent(paymentId)}`, {
              method: 'PATCH',
              body: JSON.stringify({ verificationStatus, notes }),
            });
            await loadOverview(true);
          }}
        />
      )}

      {activeSection === 'users' && (
        <UsersSection
          currentAdminUid={session.uid}
          users={overview.users}
          admins={overview.admins}
          onUpdateUser={async (uid, updates) => {
            await adminFetch(`/api/admin/users/${encodeURIComponent(uid)}`, {
              method: 'PATCH',
              body: JSON.stringify(updates),
            });
            await loadOverview(true);
          }}
        />
      )}

      {activeSection === 'analytics' && (
        <AnalyticsSection
          orders={overview.orders}
          payments={overview.payments}
          analyticsDaily={overview.analytics}
        />
      )}

      {activeSection === 'content' && (
        <ContentSection
          siteContent={overview.siteContent}
          servicePlans={overview.servicePlans}
          faqs={overview.faqs}
          onSaveHeroContent={async (doc) => {
            await adminFetch(`/api/admin/content/${encodeURIComponent(doc.sectionId)}`, {
              method: 'PUT',
              body: JSON.stringify(doc),
            });
            await loadOverview(true);
          }}
          onSaveServicePlan={async (plan) => {
            await adminFetch(`/api/admin/service-plans/${encodeURIComponent(plan.serviceId)}`, {
              method: 'PUT',
              body: JSON.stringify(plan),
            });
            await loadOverview(true);
          }}
          onDeleteServicePlan={async (serviceId) => {
            await adminFetch(`/api/admin/service-plans/${encodeURIComponent(serviceId)}`, {
              method: 'DELETE',
            });
            await loadOverview(true);
          }}
          onSaveFaq={async (faq) => {
            await adminFetch(`/api/admin/faqs/${encodeURIComponent(faq.faqId)}`, {
              method: 'PUT',
              body: JSON.stringify(faq),
            });
            await loadOverview(true);
          }}
          onDeleteFaq={async (faqId) => {
            await adminFetch(`/api/admin/faqs/${encodeURIComponent(faqId)}`, {
              method: 'DELETE',
            });
            await loadOverview(true);
          }}
        />
      )}

      {activeSection === 'settings' && (
        <SettingsSection
          settings={overview.settings[0] ?? null}
          auditLogs={overview.auditLogs}
          onSaveSettings={async (next) => {
            await adminFetch('/api/admin/settings', {
              method: 'PUT',
              body: JSON.stringify(next),
            });
            await loadOverview(true);
          }}
        />
      )}
    </AdminShell>
  );
}
