import test from 'node:test';
import assert from 'node:assert/strict';
import {
  QR_IMAGE_PATH,
  SERVICE_PLANS,
  SEED_ORDERS,
  buildUpiIntentPayload,
  buildUpiReferenceText,
  createCaseOrder,
  formatInr,
  getPaymentAppLabel,
  getServiceById,
  getStatusLabel,
  submitPaymentProof,
  submitRazorpayPayment,
  validateCaseInput,
  validateUtrNumber,
} from './paymentLogic';

test('formats INR amounts with Indian grouping', () => {
  assert.equal(formatInr(499), '₹499');
  assert.equal(formatInr(1999), '₹1,999');
});

test('looks up service plans accurately', () => {
  const starter = getServiceById('shorts-basic-claim');
  assert.ok(starter);
  assert.equal(starter.priceInr, 149);

  const plan = getServiceById('yt-content-id');
  assert.ok(plan);
  assert.equal(plan.priceInr, 499);
  assert.equal(getServiceById('missing-plan'), undefined);
  assert.equal(SERVICE_PLANS.length, 5);
  assert.equal(QR_IMAGE_PATH, '/assets/aistudio/1794605881633_020ec386.png');
});

test('validateCaseInput rejects empty or malformed fields and accepts valid input', () => {
  const invalid = validateCaseInput({
    serviceId: 'yt-content-id',
    platform: 'YouTube',
    videoUrl: 'not a url',
    claimantName: '',
    creatorName: 'A',
    contact: '12345',
  });
  assert.ok(invalid.videoUrl);
  assert.ok(invalid.creatorName);
  assert.ok(invalid.contact);

  const valid = validateCaseInput({
    serviceId: 'yt-content-id',
    platform: 'YouTube',
    videoUrl: 'https://youtube.com/watch?v=abc123',
    claimantName: 'XYZ Music',
    creatorName: 'Rohan Sharma',
    contact: '+91 9876543210',
  });
  assert.deepEqual(valid, {});

  const validEmail = validateCaseInput({
    serviceId: 'reels-audio-unblock',
    platform: 'Instagram Reels',
    videoUrl: 'instagram.com/reel/C9xyz',
    claimantName: '',
    creatorName: 'Priya Nair',
    contact: 'priya@studio.in',
  });
  assert.deepEqual(validEmail, {});
});

test('validateUtrNumber enforces exact 12-digit numeric UTR', () => {
  assert.equal(validateUtrNumber('').valid, false);
  assert.equal(validateUtrNumber('12345678901').valid, false);
  assert.equal(validateUtrNumber('12345678901A').valid, false);

  const ok = validateUtrNumber('6318 4920 1458');
  assert.equal(ok.valid, true);
  assert.equal(ok.normalized, '631849201458');
});

test('createCaseOrder and submitPaymentProof transition order state cleanly', () => {
  const order = createCaseOrder(
    {
      serviceId: 'copyright-strike',
      platform: 'YouTube',
      videoUrl: 'youtu.be/xyz999',
      claimantName: 'Alpha Label',
      creatorName: 'Kabir Sen',
      contact: '9811122334',
    },
    SEED_ORDERS,
    '2026-11-13T10:00:00.000Z'
  );

  assert.match(order.caseId, /^CR-2026-\d{4}$/);
  assert.equal(order.amountInr, 1499);
  assert.equal(order.videoUrl, 'https://youtu.be/xyz999');
  assert.equal(order.status, 'awaiting_payment');
  assert.equal(getStatusLabel(order.status), 'Awaiting UPI Payment');

  assert.throws(() => submitPaymentProof(order, 'gpay', '123'));

  const paid = submitPaymentProof(order, 'phonepe', '6318 9900 1122', '2026-11-13T10:05:00.000Z');
  assert.equal(paid.status, 'verifying_payment');
  assert.equal(paid.paymentApp, 'phonepe');
  assert.equal(paid.utrNumber, '631899001122');
  assert.equal(getPaymentAppLabel(paid.paymentApp), 'PhonePe');
  assert.equal(
    buildUpiReferenceText(paid),
    `${paid.caseId} | Copyright Strike Retraction | ₹1,499`
  );
  assert.ok(buildUpiIntentPayload({ amountInr: 499, caseId: 'CR-2026-1042', serviceTitle: 'Test' }).includes('am=499'));
});

test('submitRazorpayPayment records verified Razorpay order and payment IDs', () => {
  const order = createCaseOrder(
    {
      serviceId: 'shorts-basic-claim',
      platform: 'YouTube Shorts',
      videoUrl: 'https://youtube.com/shorts/abc123',
      claimantName: 'Sample Audio',
      creatorName: 'Riya Kapoor',
      contact: 'riya@example.com',
    },
    SEED_ORDERS,
    '2026-11-19T10:00:00.000Z'
  );

  assert.throws(() =>
    submitRazorpayPayment(order, { razorpayOrderId: '', razorpayPaymentId: 'pay_123' })
  );

  const verified = submitRazorpayPayment(order, {
    razorpayOrderId: 'order_Rzp123456',
    razorpayPaymentId: 'pay_Rzp987654',
    paidAtIso: '2026-11-19T10:02:00.000Z',
  });

  assert.equal(verified.status, 'dispute_filed');
  assert.equal(verified.paymentMethod, 'razorpay');
  assert.equal(verified.razorpayOrderId, 'order_Rzp123456');
  assert.equal(verified.razorpayPaymentId, 'pay_Rzp987654');
  assert.equal(verified.paidAt, '2026-11-19T10:02:00.000Z');
});

