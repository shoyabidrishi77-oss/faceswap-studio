export type PlatformType = 'YouTube' | 'Instagram Reels' | 'Facebook Video' | 'YouTube Shorts';

export type UpiAppId = 'phonepe' | 'gpay' | 'paytm' | 'qr';

export type OrderStatus =
  | 'awaiting_payment'
  | 'verifying_payment'
  | 'dispute_filed'
  | 'claim_released';

export type PaymentGatewayMode = 'upi' | 'razorpay';

export interface ServicePlan {
  id: string;
  code: string;
  title: string;
  subtitle: string;
  priceInr: number;
  turnaround: string;
  scope: string;
  deliverables: string[];
}

export interface CaseInput {
  serviceId: string;
  platform: PlatformType;
  videoUrl: string;
  claimantName: string;
  creatorName: string;
  contact: string;
}

export interface CaseValidationErrors {
  videoUrl?: string;
  creatorName?: string;
  contact?: string;
  serviceId?: string;
}

export interface CaseOrder {
  caseId: string;
  serviceId: string;
  serviceTitle: string;
  platform: PlatformType;
  videoUrl: string;
  claimantName: string;
  creatorName: string;
  contact: string;
  amountInr: number;
  status: OrderStatus;
  paymentMethod?: PaymentGatewayMode;
  paymentApp?: UpiAppId;
  utrNumber?: string;
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  createdAt: string;
  paidAt?: string;
}

export const QR_IMAGE_PATH = '/assets/aistudio/1794605881633_020ec386.png';

export const PLATFORMS: PlatformType[] = [
  'YouTube',
  'Instagram Reels',
  'Facebook Video',
  'YouTube Shorts',
];

export const SERVICE_PLANS: ServicePlan[] = [
  {
    id: 'shorts-basic-claim',
    code: '01',
    title: 'Shorts & Single Clip Claim',
    subtitle: 'Starter clearance for YouTube Shorts, short audio matches, and claim audit.',
    priceInr: 149,
    turnaround: '6–24 hours',
    scope: '1 Short / Clip',
    deliverables: [
      'Claimant & audio match audit',
      'Shorts / short-clip dispute filing',
      'Live Case Tracker status updates',
    ],
  },
  {
    id: 'reels-audio-unblock',
    code: '02',
    title: 'Instagram Reels Audio Unblock',
    subtitle: 'Clear muted audio or regional block notices on Reels and Facebook clips.',
    priceInr: 399,
    turnaround: '12–36 hours',
    scope: '1 Reel / Post',
    deliverables: [
      'Meta Rights Manager appeal',
      'Audio ownership verification',
      'Distribution block removal',
    ],
  },
  {
    id: 'yt-content-id',
    code: '03',
    title: 'YouTube Content ID Claim',
    subtitle: 'Single-video audio or visual match claim dispute and monetization restore.',
    priceInr: 499,
    turnaround: '24–48 hours',
    scope: '1 Video URL',
    deliverables: [
      'Claimant rights & license audit',
      'Formal Content ID dispute filing',
      'Revenue escrow release tracking',
    ],
  },
  {
    id: 'copyright-strike',
    code: '04',
    title: 'Copyright Strike Retraction',
    subtitle: 'Formal DMCA counter-notification and direct claimant retraction outreach.',
    priceInr: 1499,
    turnaround: '2–5 business days',
    scope: '1 Active Strike',
    deliverables: [
      'DMCA counter-notice drafting',
      'Claimant retraction follow-up',
      'Channel standing protection brief',
    ],
  },
  {
    id: 'channel-cleanup-pack',
    code: '05',
    title: 'Channel Clean-Up Pack',
    subtitle: 'Bulk clearance for up to 5 claimed videos across your creator catalog.',
    priceInr: 1999,
    turnaround: '48–72 hours',
    scope: 'Up to 5 Videos',
    deliverables: [
      'Batch Content ID claim disputes',
      'Monetization eligibility check',
      'Dedicated case summary report',
    ],
  },
];

export interface UpiAppMeta {
  id: UpiAppId;
  label: string;
  shortTag: string;
  utrHint: string;
  stepGuide: string;
}

export const UPI_APPS: UpiAppMeta[] = [
  {
    id: 'phonepe',
    label: 'PhonePe',
    shortTag: 'Pe',
    utrHint: 'Open PhonePe History → Select transaction → Copy 12-digit UTR number.',
    stepGuide: 'Open PhonePe, tap Scan & Pay, scan the verified UPI QR above, and pay the exact amount.',
  },
  {
    id: 'gpay',
    label: 'Google Pay',
    shortTag: 'GPay',
    utrHint: 'Open Google Pay → See payment details → Copy 12-digit UPI transaction ID.',
    stepGuide: 'Open Google Pay, choose Scan any QR code, scan the verified UPI QR above, and pay.',
  },
  {
    id: 'paytm',
    label: 'Paytm',
    shortTag: 'Paytm',
    utrHint: 'Open Paytm Balance & History → Tap payment → Copy 12-digit UPI Ref No.',
    stepGuide: 'Open Paytm, tap Scan & Pay, scan the verified UPI QR above, and confirm payment.',
  },
  {
    id: 'qr',
    label: 'BHIM UPI',
    shortTag: 'UPI',
    utrHint: 'Find the 12-digit UPI Ref / RRN inside your banking or BHIM receipt.',
    stepGuide: 'Scan the verified UPI QR code above using BHIM, Amazon Pay, or any bank UPI app.',
  },
];

export const SEED_ORDERS: CaseOrder[] = [
  {
    caseId: 'CR-2026-1042',
    serviceId: 'yt-content-id',
    serviceTitle: 'YouTube Content ID Claim',
    platform: 'YouTube',
    videoUrl: 'https://www.youtube.com/watch?v=sample9481',
    claimantName: 'Meridian Audio Distribution',
    creatorName: 'Aarav Verma',
    contact: '+91 98765 43210',
    amountInr: 499,
    status: 'claim_released',
    paymentApp: 'phonepe',
    utrNumber: '631849201458',
    createdAt: '2026-11-11T10:15:00.000Z',
    paidAt: '2026-11-11T10:19:00.000Z',
  },
  {
    caseId: 'CR-2026-0987',
    serviceId: 'copyright-strike',
    serviceTitle: 'Copyright Strike Retraction',
    platform: 'YouTube',
    videoUrl: 'https://youtu.be/demo7742',
    claimantName: 'Studio Frame Media',
    creatorName: 'Neha Kulkarni',
    contact: 'neha.k@creatorstudio.in',
    amountInr: 1499,
    status: 'dispute_filed',
    paymentApp: 'gpay',
    utrNumber: '631720554901',
    createdAt: '2026-11-12T14:30:00.000Z',
    paidAt: '2026-11-12T14:35:00.000Z',
  },
];

export function formatInr(amount: number): string {
  return `₹${amount.toLocaleString('en-IN')}`;
}

export function getServiceById(serviceId: string): ServicePlan | undefined {
  return SERVICE_PLANS.find((plan) => plan.id === serviceId);
}

export function isValidUrl(raw: string): boolean {
  const trimmed = raw.trim();
  if (!trimmed) return false;
  try {
    const normalized = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
    const parsed = new URL(normalized);
    return Boolean(parsed.hostname && parsed.hostname.includes('.'));
  } catch {
    return false;
  }
}

export function normalizeUrl(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return '';
  return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
}

export function isValidContact(raw: string): boolean {
  const trimmed = raw.trim();
  if (!trimmed) return false;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  if (emailRegex.test(trimmed)) return true;

  const digits = trimmed.replace(/[\s\-+()]/g, '');
  if (/^(91)?[6-9]\d{9}$/.test(digits)) return true;
  return false;
}

export function validateCaseInput(input: CaseInput): CaseValidationErrors {
  const errors: CaseValidationErrors = {};
  if (!getServiceById(input.serviceId)) {
    errors.serviceId = 'Please choose a valid copyright removal service.';
  }
  if (!isValidUrl(input.videoUrl)) {
    errors.videoUrl = 'Enter a valid video or reel URL (for example, https://youtube.com/watch?v=...).';
  }
  if (input.creatorName.trim().length < 2) {
    errors.creatorName = 'Enter your full name or channel name (at least 2 characters).';
  }
  if (!isValidContact(input.contact)) {
    errors.contact = 'Enter a valid 10-digit WhatsApp/mobile number or email address.';
  }
  return errors;
}

export function normalizeUtr(raw: string): string {
  return raw.replace(/\s+/g, '').trim();
}

export function validateUtrNumber(raw: string): { valid: boolean; normalized: string; error?: string } {
  const normalized = normalizeUtr(raw);
  if (!normalized) {
    return {
      valid: false,
      normalized,
      error: 'Enter the 12-digit UPI UTR / Reference number from your payment receipt.',
    };
  }
  if (!/^\d{12}$/.test(normalized)) {
    return {
      valid: false,
      normalized,
      error: 'UPI UTR / Reference number must be exactly 12 digits (no letters or symbols).',
    };
  }
  return { valid: true, normalized };
}

export function generateCaseId(existingIds: string[]): string {
  const existingSet = new Set(existingIds);
  for (let i = 0; i < 20; i += 1) {
    const suffix = Math.floor(1000 + Math.random() * 9000);
    const candidate = `CR-2026-${suffix}`;
    if (!existingSet.has(candidate)) {
      return candidate;
    }
  }
  return `CR-2026-${Date.now().toString().slice(-4)}`;
}

export function createCaseOrder(input: CaseInput, existingOrders: CaseOrder[], nowIso?: string): CaseOrder {
  const service = getServiceById(input.serviceId);
  if (!service) {
    throw new Error(`Unknown service plan: ${input.serviceId}`);
  }
  const caseId = generateCaseId(existingOrders.map((o) => o.caseId));
  return {
    caseId,
    serviceId: service.id,
    serviceTitle: service.title,
    platform: input.platform,
    videoUrl: normalizeUrl(input.videoUrl),
    claimantName: input.claimantName.trim() || 'Not specified',
    creatorName: input.creatorName.trim(),
    contact: input.contact.trim(),
    amountInr: service.priceInr,
    status: 'awaiting_payment',
    createdAt: nowIso ?? new Date().toISOString(),
  };
}

export function submitPaymentProof(
  order: CaseOrder,
  paymentApp: UpiAppId,
  rawUtr: string,
  paidAtIso?: string
): CaseOrder {
  const check = validateUtrNumber(rawUtr);
  if (!check.valid) {
    throw new Error(check.error ?? 'Invalid UTR number');
  }
  return {
    ...order,
    status: 'verifying_payment',
    paymentMethod: 'upi',
    paymentApp,
    utrNumber: check.normalized,
    paidAt: paidAtIso ?? new Date().toISOString(),
  };
}

export function submitRazorpayPayment(
  order: CaseOrder,
  details: {
    razorpayOrderId: string;
    razorpayPaymentId: string;
    paidAtIso?: string;
  }
): CaseOrder {
  const razorpayOrderId = details.razorpayOrderId.trim();
  const razorpayPaymentId = details.razorpayPaymentId.trim();
  if (!razorpayOrderId || !razorpayPaymentId) {
    throw new Error('Verified Razorpay order ID and payment ID are required.');
  }
  return {
    ...order,
    status: 'dispute_filed',
    paymentMethod: 'razorpay',
    razorpayOrderId,
    razorpayPaymentId,
    paidAt: details.paidAtIso ?? new Date().toISOString(),
  };
}

export function buildUpiReferenceText(order: Pick<CaseOrder, 'caseId' | 'amountInr' | 'serviceTitle'>): string {
  return `${order.caseId} | ${order.serviceTitle} | ${formatInr(order.amountInr)}`;
}

export function buildUpiIntentPayload(params: {
  amountInr: number;
  caseId?: string;
  serviceTitle: string;
}): string {
  const note = params.caseId
    ? `CR Remover ${params.caseId}`
    : `CR Remover ${params.serviceTitle}`;
  return `upi://pay?pn=CR%20Remover&am=${params.amountInr}&cu=INR&tn=${encodeURIComponent(note)}`;
}

export function getStatusLabel(status: OrderStatus): string {
  switch (status) {
    case 'awaiting_payment':
      return 'Awaiting UPI Payment';
    case 'verifying_payment':
      return 'Payment Under Verification';
    case 'dispute_filed':
      return 'Dispute Filed with Platform';
    case 'claim_released':
      return 'Claim Released';
  }
}

export function getPaymentAppLabel(app?: UpiAppId): string {
  if (!app) return 'Pending';
  return UPI_APPS.find((item) => item.id === app)?.label ?? 'UPI';
}
