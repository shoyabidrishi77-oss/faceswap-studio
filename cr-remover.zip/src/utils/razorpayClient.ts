export interface RazorpayPublicConfig {
  configured: boolean;
  mode: 'live' | 'test' | 'unconfigured';
  keyId: string | null;
}

export interface RazorpayCreateOrderResponse {
  orderId: string;
  amountPaise: number;
  amountInr: number;
  currency: string;
  keyId: string;
  caseId: string;
  serviceTitle: string;
}

export interface RazorpayVerifyResponse {
  verified: boolean;
  caseId: string;
  razorpayOrderId: string;
  razorpayPaymentId: string;
  paidAt: string;
}

interface RazorpayHandlerResponse {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
}

interface RazorpayCheckoutOptions {
  key: string;
  amount: number;
  currency: string;
  name: string;
  description: string;
  order_id: string;
  image?: string;
  prefill?: {
    name?: string;
    email?: string;
    contact?: string;
  };
  notes?: Record<string, string>;
  theme?: {
    color?: string;
  };
  handler: (response: RazorpayHandlerResponse) => void;
  modal?: {
    ondismiss?: () => void;
  };
}

interface RazorpayInstance {
  open: () => void;
  on: (event: string, cb: (err: { error?: { description?: string } }) => void) => void;
}

declare global {
  interface Window {
    Razorpay?: new (options: RazorpayCheckoutOptions) => RazorpayInstance;
  }
}

const CHECKOUT_SCRIPT_SRC = 'https://checkout.razorpay.com/v1/checkout.js';
let scriptLoaderPromise: Promise<void> | null = null;

export function loadRazorpayCheckoutScript(): Promise<void> {
  if (typeof window !== 'undefined' && typeof window.Razorpay === 'function') {
    return Promise.resolve();
  }
  if (scriptLoaderPromise) {
    return scriptLoaderPromise;
  }

  scriptLoaderPromise = new Promise((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>(
      `script[src="${CHECKOUT_SCRIPT_SRC}"]`
    );
    if (existing) {
      existing.addEventListener('load', () => resolve(), { once: true });
      existing.addEventListener('error', () => reject(new Error('Failed to load Razorpay Checkout SDK.')), {
        once: true,
      });
      return;
    }

    const script = document.createElement('script');
    script.src = CHECKOUT_SCRIPT_SRC;
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => {
      scriptLoaderPromise = null;
      reject(new Error('Failed to load Razorpay Checkout SDK. Check your internet connection.'));
    };
    document.head.appendChild(script);
  });

  return scriptLoaderPromise;
}

export async function fetchRazorpayPublicConfig(): Promise<RazorpayPublicConfig> {
  const res = await fetch('/api/payments/razorpay/config');
  if (!res.ok) {
    throw new Error('Unable to check Razorpay gateway status.');
  }
  return (await res.json()) as RazorpayPublicConfig;
}

export async function initiateRazorpayCheckout(params: {
  caseId: string;
  serviceId: string;
  platform: string;
  creatorName: string;
  contact: string;
}): Promise<RazorpayVerifyResponse> {
  const createRes = await fetch('/api/payments/razorpay/order', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      caseId: params.caseId,
      serviceId: params.serviceId,
      platform: params.platform,
      creatorName: params.creatorName,
    }),
  });

  const createPayload = (await createRes.json().catch(() => ({}))) as Partial<RazorpayCreateOrderResponse> & {
    error?: string;
  };
  if (!createRes.ok || !createPayload.orderId || !createPayload.keyId) {
    throw new Error(createPayload.error ?? 'Failed to initialize Razorpay order.');
  }

  await loadRazorpayCheckoutScript();
  if (typeof window.Razorpay !== 'function') {
    throw new Error('Razorpay Checkout SDK is unavailable in this browser.');
  }

  const trimmedContact = params.contact.trim();
  const isEmail = trimmedContact.includes('@');

  return new Promise<RazorpayVerifyResponse>((resolve, reject) => {
    const RazorpayCtor = window.Razorpay!;
    const instance = new RazorpayCtor({
      key: createPayload.keyId!,
      amount: createPayload.amountPaise!,
      currency: createPayload.currency ?? 'INR',
      name: 'CR Remover',
      description: `${createPayload.serviceTitle ?? 'Copyright Claim Removal'} · ${params.caseId}`,
      image: '/logo-transparent.png',
      order_id: createPayload.orderId!,
      prefill: {
        name: params.creatorName,
        ...(isEmail ? { email: trimmedContact } : { contact: trimmedContact }),
      },
      notes: {
        caseId: params.caseId,
        serviceId: params.serviceId,
      },
      theme: {
        color: '#1E40AF',
      },
      handler: async (paymentResult) => {
        try {
          const verifyRes = await fetch('/api/payments/razorpay/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              caseId: params.caseId,
              razorpayOrderId: paymentResult.razorpay_order_id,
              razorpayPaymentId: paymentResult.razorpay_payment_id,
              razorpaySignature: paymentResult.razorpay_signature,
            }),
          });
          const verifyData = (await verifyRes.json().catch(() => ({}))) as Partial<RazorpayVerifyResponse> & {
            error?: string;
          };
          if (!verifyRes.ok || !verifyData.verified) {
            reject(new Error(verifyData.error ?? 'Razorpay signature verification failed.'));
            return;
          }
          resolve(verifyData as RazorpayVerifyResponse);
        } catch (err) {
          reject(err instanceof Error ? err : new Error('Failed to verify Razorpay payment.'));
        }
      },
      modal: {
        ondismiss: () => {
          reject(new Error('Razorpay checkout window was closed before completing payment.'));
        },
      },
    });

    instance.on('payment.failed', (failure) => {
      reject(
        new Error(failure?.error?.description ?? 'Razorpay payment failed. Please try again or use UPI QR.')
      );
    });

    instance.open();
  });
}
